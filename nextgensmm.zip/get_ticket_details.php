<?php
session_start();
require_once 'config/db.php';
$db = $conn;

if (!isset($_SESSION['user_id']) || !isset($_GET['id'])) {
    die("Yetkisiz erişim!");
}

try {
    $ticket_id = $_GET['id'];
    $user_id = $_SESSION['user_id'];

    // Ticket bilgilerini al
    $stmt = $db->prepare("
        SELECT t.*, u.username 
        FROM tickets t 
        JOIN users u ON t.user_id = u.id 
        WHERE t.id = ? AND t.user_id = ?
    ");
    $stmt->execute([$ticket_id, $user_id]);
    $ticket = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$ticket) {
        die("Destek talebi bulunamadı!");
    }

    // Yanıtları al
    $stmt = $db->prepare("
        SELECT tr.*, u.username, u.role 
        FROM ticket_replies tr 
        JOIN users u ON tr.user_id = u.id 
        WHERE tr.ticket_id = ? 
        ORDER BY tr.created_at ASC
    ");
    $stmt->execute([$ticket_id]);
    $replies = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<div class="space-y-6">
    <!-- Ticket Detayları -->
    <div class="bg-gray-800/50 rounded-lg p-4">
        <h4 class="text-lg font-semibold text-white mb-2"><?php echo htmlspecialchars($ticket['subject']); ?></h4>
        <p class="text-gray-300 mb-4"><?php echo nl2br(htmlspecialchars($ticket['message'])); ?></p>
        <div class="text-sm text-gray-400">
            <?php echo date('d.m.Y H:i', strtotime($ticket['created_at'])); ?> tarihinde oluşturuldu
        </div>
    </div>

    <!-- Yanıtlar -->
    <div class="space-y-4">
        <?php foreach ($replies as $reply): ?>
        <div class="bg-gray-800/30 rounded-lg p-4">
            <div class="flex justify-between items-start mb-2">
                <div class="flex items-center">
                    <span class="font-medium text-white"><?php echo htmlspecialchars($reply['username']); ?></span>
                    <?php if ($reply['role'] === 'admin'): ?>
                    <span class="ml-2 px-2 py-1 text-xs bg-red-500 text-white rounded">Admin</span>
                    <?php endif; ?>
                </div>
                <span class="text-sm text-gray-400">
                    <?php echo date('d.m.Y H:i', strtotime($reply['created_at'])); ?>
                </span>
            </div>
            <p class="text-gray-300"><?php echo nl2br(htmlspecialchars($reply['message'])); ?></p>
        </div>
        <?php endforeach; ?>
    </div>

    <!-- Yanıt Formu -->
    <?php if ($ticket['status'] !== 'closed'): ?>
    <form action="support.php" method="POST" class="space-y-4">
        <input type="hidden" name="action" value="reply">
        <input type="hidden" name="ticket_id" value="<?php echo $ticket_id; ?>">
        <div>
            <label class="block text-gray-400 mb-2">Yanıtınız</label>
            <textarea name="message" rows="4" class="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-blue-500" required></textarea>
        </div>
        <button type="submit" class="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-6 py-2 rounded-lg hover:opacity-90 transition-opacity">
            Yanıt Gönder
        </button>
    </form>
    <?php else: ?>
    <div class="text-center text-gray-400 py-4">
        Bu destek talebi kapatılmıştır.
    </div>
    <?php endif; ?>
</div>

<?php
} catch (Exception $e) {
    echo "Bir hata oluştu: " . $e->getMessage();
}
?>