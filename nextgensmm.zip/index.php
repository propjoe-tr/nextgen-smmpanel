<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NextGen SMM Panel</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css" />
    <style>
        .neo-gradient {
            background: linear-gradient(120deg, #2E3192, #1BFFFF);
        }
        .card-hover {
            transition: all 0.3s ease;
        }
        .card-hover:hover {
            transform: translateY(-10px);
            box-shadow: 0 20px 40px rgba(0,0,0,0.2);
        }
        .text-gradient {
            background: linear-gradient(to right, #1BFFFF, #2E3192);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .blur-backdrop {
            backdrop-filter: blur(20px);
            background: rgba(255, 255, 255, 0.05);
        }
        .mobile-menu {
            transition: all 0.3s ease;
        }
    </style>
</head>
<body class="bg-[#0A0A1B] min-h-screen">
    <!-- Animasyonlu Arka Plan -->
    <div class="fixed inset-0 opacity-30">
        <div class="absolute inset-0 neo-gradient opacity-20"></div>
        <div class="absolute top-0 left-0 w-96 h-96 bg-blue-500 rounded-full mix-blend-multiply filter blur-3xl animate-blob"></div>
        <div class="absolute top-0 right-0 w-96 h-96 bg-purple-500 rounded-full mix-blend-multiply filter blur-3xl animate-blob animation-delay-2000"></div>
    </div>

    <!-- Navbar -->
    <nav class="fixed w-full z-50 blur-backdrop">
        <div class="container mx-auto px-6 py-4">
            <div class="flex items-center justify-between">
                <div class="text-2xl font-bold text-gradient">NEXTGEN SMM</div>
                
                <!-- Mobil Menü Butonu -->
                <button class="md:hidden text-white" id="mobileMenuButton">
                    <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16M4 18h16"></path>
                    </svg>
                </button>

                <!-- Desktop Menü -->
                <div class="hidden md:flex items-center space-x-8">
                    <div class="flex items-center space-x-8">
                        <a href="#" class="text-gray-300 hover:text-white transition-colors font-medium">Ana Sayfa</a>
                        <a href="#services" class="text-gray-300 hover:text-white transition-colors font-medium">Servisler</a>
                        <a href="#" class="text-gray-300 hover:text-white transition-colors font-medium">API</a>
                    </div>
                    <?php if (!isset($_SESSION['user'])): ?>
                        <a href="login.php" class="px-6 py-2 rounded-full bg-gradient-to-r from-blue-500 to-purple-600 text-white hover:opacity-90 transition-opacity font-medium">
                            Giriş Yap
                        </a>
                    <?php else: ?>
                        <a href="dashboard.php" class="px-6 py-2 rounded-full bg-gradient-to-r from-blue-500 to-purple-600 text-white hover:opacity-90 transition-opacity font-medium">
                            Panel
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Mobil Menü -->
        <div class="hidden mobile-menu md:hidden">
            <div class="px-2 pt-2 pb-3 space-y-1 blur-backdrop">
                <a href="#" class="block px-3 py-2 text-gray-300 hover:text-white transition-colors font-medium">Ana Sayfa</a>
                <a href="#services" class="block px-3 py-2 text-gray-300 hover:text-white transition-colors font-medium">Servisler</a>
                <a href="#" class="block px-3 py-2 text-gray-300 hover:text-white transition-colors font-medium">API</a>
                <?php if (!isset($_SESSION['user'])): ?>
                    <a href="login.php" class="block px-3 py-2 text-gray-300 hover:text-white transition-colors font-medium">Giriş Yap</a>
                <?php endif; ?>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <main class="relative">
        <section class="container mx-auto px-6 pt-32 pb-20">
            <div class="text-center" data-aos="fade-up">
                <h1 class="text-4xl md:text-6xl font-bold text-white mb-6">
                    Sosyal Medya'da<br>
                    <span class="text-gradient">Yeni Nesil Güç</span>
                </h1>
                <p class="text-gray-400 text-lg md:text-xl mb-12 max-w-2xl mx-auto">
                    Yapay zeka destekli SMM panel ile sosyal medya hesaplarınızı 
                    büyütmenin en akıllı yolu
                </p>
                <div class="flex flex-col md:flex-row justify-center gap-4 md:gap-6">
                    <a href="register.php" class="px-8 py-4 rounded-full bg-gradient-to-r from-blue-500 to-purple-600 text-white hover:opacity-90 transition-opacity">
                        Ücretsiz Başla
                    </a>
                    <a href="#services" class="px-8 py-4 rounded-full border border-gray-600 text-white hover:border-blue-500 transition-colors">
                        Servisleri Keşfet
                    </a>
                </div>
            </div>
        </section>

        <!-- İstatistikler -->
        <section class="container mx-auto px-6 py-20">
            <div class="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
                <?php
                $stats = [
                    ['number' => '10K+', 'text' => 'Mutlu Müşteri'],
                    ['number' => '50M+', 'text' => 'Başarılı İşlem'],
                    ['number' => '99.9%', 'text' => 'Başarı Oranı'],
                    ['number' => '24/7', 'text' => 'Destek']
                ];
                foreach ($stats as $stat): ?>
                    <div class="blur-backdrop p-6 rounded-2xl card-hover" data-aos="fade-up">
                        <div class="text-3xl md:text-4xl font-bold text-gradient mb-2"><?= $stat['number'] ?></div>
                        <div class="text-gray-400"><?= $stat['text'] ?></div>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>

        <!-- Servisler -->
        <section id="services" class="container mx-auto px-6 py-20">
            <h2 class="text-3xl md:text-4xl font-bold text-white text-center mb-12" data-aos="fade-up">Premium Servislerimiz</h2>
            <div class="grid md:grid-cols-3 gap-8">
                <?php
                $services = [
                    [
                        'icon' => '<svg class="w-12 h-12" fill="currentColor" viewBox="0 0 24 24"><path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2.163c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z"/></svg>',
                        'title' => 'Instagram',
                        'desc' => 'Takipçi, beğeni ve etkileşim paketleri'
                    ],
                    [
                        'icon' => '<svg class="w-12 h-12" fill="currentColor" viewBox="0 0 24 24"><path d="M19.615 3.184c-3.604-.246-11.631-.245-15.23 0-3.897.266-4.356 2.62-4.385 8.816.029 6.185.484 8.549 4.385 8.816 3.6.245 11.626.246 15.23 0 3.897-.266 4.356-2.62 4.385-8.816-.029-6.185-.484-8.549-4.385-8.816zm-10.615 12.816v-8l8 3.993-8 4.007z"/></svg>',
                        'title' => 'YouTube',
                        'desc' => 'Abone, izlenme ve etkileşim artırma'
                    ],
                    [
                        'icon' => '<svg class="w-12 h-12" fill="currentColor" viewBox="0 0 24 24"><path d="M12.525.02c1.31-.02 2.61-.01 3.91-.02.08 1.53.63 3.09 1.75 4.17 1.12 1.11 2.7 1.62 4.24 1.79v4.03c-1.44-.05-2.89-.35-4.2-.97-.57-.26-1.1-.59-1.62-.93-.01 2.92.01 5.84-.02 8.75-.08 1.4-.54 2.79-1.35 3.94-1.31 1.92-3.58 3.17-5.91 3.21-1.43.08-2.86-.31-4.08-1.03-2.02-1.19-3.44-3.37-3.65-5.71-.02-.5-.03-1-.01-1.49.18-1.9 1.12-3.72 2.58-4.96 1.66-1.44 3.98-2.13 6.15-1.72.02 1.48-.04 2.96-.04 4.44-.99-.32-2.15-.23-3.02.37-.63.41-1.11 1.04-1.36 1.75-.21.51-.15 1.07-.14 1.61.24 1.64 1.82 3.02 3.5 2.87 1.12-.01 2.19-.66 2.77-1.61.19-.33.4-.67.41-1.06.1-1.79.06-3.57.07-5.36.01-4.03-.01-8.05.02-12.07z"/></svg>',
                        'title' => 'TikTok',
                        'desc' => 'Takipçi ve etkileşim artırma'
                    ]
                ];

                foreach ($services as $service): ?>
                    <div class="blur-backdrop p-8 rounded-2xl card-hover" data-aos="fade-up">
                        <div class="text-blue-400 mb-6"><?= $service['icon'] ?></div>
                        <h3 class="text-2xl font-bold text-white mb-4"><?= $service['title'] ?></h3>
                        <p class="text-gray-400"><?= $service['desc'] ?></p>
                        <a href="#" class="inline-block mt-6 text-blue-400 hover:text-blue-300">Detaylı Bilgi →</a>
                    </div>
                <?php endforeach; ?>
            </div>
        </section>
    </main>

    <footer class="container mx-auto px-6 py-12 text-center text-gray-400">
        <p>&copy; <?= date('Y') ?> NextGen SMM. Tüm hakları saklıdır.</p>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
    <script>
        // AOS Animasyon Kütüphanesi Başlatma
        AOS.init({
            duration: 1000,
            once: true
        });

        // Mobil Menü Kontrolü
        document.getElementById('mobileMenuButton').addEventListener('click', function() {
            document.querySelector('.mobile-menu').classList.toggle('hidden');
        });

        // Smooth Scroll
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function (e) {
                e.preventDefault();
                document.querySelector(this.getAttribute('href')).scrollIntoView({
                    behavior: 'smooth'
                });
            });
        });

        // Animasyonlu blob efekti için
        const style = document.createElement('style');
        style.textContent = `
            @keyframes blob {
                0% { transform: translate(0px, 0px) scale(1); }
                33% { transform: translate(30px, -50px) scale(1.1); }
                66% { transform: translate(-20px, 20px) scale(0.9); }
                100% { transform: translate(0px, 0px) scale(1); }
            }
            .animate-blob {
                animation: blob 7s infinite;
            }
            .animation-delay-2000 {
                animation-delay: 2s;
            }
        `;
        document.head.appendChild(style);
    </script>
</body>
</html>