<?php
$host = 'localhost';          // Veritabanı sunucusu
$dbname = 'Veritabanı ADI';    // Veritabanı adı
$username = 'Kullanıcı Adı';      // Veritabanı kullanıcı adı
$password = 'Şifre';    // Veritabanı şifresi

try {
    $conn = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8mb4", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    $conn->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);
} catch(PDOException $e) {
    die("Veritabanı bağlantı hatası: " . $e->getMessage());
}

// Zaman dilimini ayarla
date_default_timezone_set('Europe/Istanbul');

// Session başlatma kontrolü
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}