<?php
// Hata raporlamayı açalım (geliştirme aşamasında)
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

// Veritabanı bağlantısını kontrol et
require_once 'config/db.php';
$db = $conn;
if (!isset($db)) {
    die("Veritabanı bağlantısı kurulamadı!");
}

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Kullanıcı bilgilerini al
try {
    $user_id = $_SESSION['user_id'];
    $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        throw new Exception("Kullanıcı bulunamadı");
    }

    // Kategorileri getir
    $categoryQuery = "SELECT * FROM categories WHERE status = 'active' ORDER BY sort_order ASC";
    $categories = $db->query($categoryQuery)->fetchAll(PDO::FETCH_ASSOC);

    // Her kategori için servisleri getir
    $services = [];
    foreach ($categories as $category) {
        $serviceQuery = "SELECT * FROM services WHERE category_id = ? AND status = 'active' ORDER BY price ASC";
        $stmt = $db->prepare($serviceQuery);
        $stmt->execute([$category['id']]);
        $services[$category['id']] = $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

} catch (Exception $e) {
    die("Bir hata oluştu: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Servisler - NextGen SMM Panel</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css" />
    <style>
        .neo-gradient {
            background: linear-gradient(120deg, #2E3192, #1BFFFF);
        }
        .card-hover {
            transition: all 0.3s ease;
        }
        .card-hover:hover {
            transform: translateY(-10px);
            box-shadow: 0 20px 40px rgba(0,0,0,0.2);
        }
        .text-gradient {
            background: linear-gradient(to right, #1BFFFF, #2E3192);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .blur-backdrop {
            backdrop-filter: blur(20px);
            background: rgba(255, 255, 255, 0.05);
        }
        .mobile-menu {
            transition: all 0.3s ease;
        }
        .sidebar {
            width: 280px;
            transition: all 0.3s ease;
        }
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }
            .sidebar.active {
                transform: translateX(0);
            }
        }
    </style>
</head>
<body class="bg-[#0A0A1B] min-h-screen">
    <!-- Animasyonlu Arka Plan -->
    <div class="fixed inset-0 opacity-30">
        <div class="absolute inset-0 neo-gradient opacity-20"></div>
        <div class="absolute top-0 left-0 w-96 h-96 bg-blue-500 rounded-full mix-blend-multiply filter blur-3xl animate-blob"></div>
        <div class="absolute top-0 right-0 w-96 h-96 bg-purple-500 rounded-full mix-blend-multiply filter blur-3xl animate-blob animation-delay-2000"></div>
    </div>

    <!-- Sol Sidebar -->
    <aside class="sidebar fixed left-0 top-0 h-full blur-backdrop z-50">
        <div class="p-6">
            <div class="text-2xl font-bold text-gradient mb-8">NEXTGEN SMM</div>
            
            <!-- Kullanıcı Profili -->
            <div class="mb-8 text-center">
                <div class="w-20 h-20 rounded-full bg-gradient-to-r from-blue-500 to-purple-600 mx-auto mb-3 flex items-center justify-center">
                    <i class="fas fa-user text-white text-2xl"></i>
                </div>
                <div class="text-white font-medium"><?php echo htmlspecialchars($user['username']); ?></div>
                <div class="text-sm text-gray-400"><?php echo htmlspecialchars($user['email']); ?></div>
            </div>

            <!-- Menü -->
            <nav class="space-y-2">
                <a href="dashboard.php" class="flex items-center space-x-3 p-3 rounded-lg hover:bg-white/10 text-gray-300 hover:text-white transition-colors">
                    <i class="fas fa-home w-5"></i>
                    <span>Ana Sayfa</span>
                </a>
                <a href="services.php" class="flex items-center space-x-3 p-3 rounded-lg bg-white/10 text-white">
                    <i class="fas fa-list w-5"></i>
                    <span>Servisler</span>
                </a>
                <a href="new-order.php" class="flex items-center space-x-3 p-3 rounded-lg hover:bg-white/10 text-gray-300 hover:text-white transition-colors">
                    <i class="fas fa-shopping-cart w-5"></i>
                    <span>Yeni Sipariş</span>
                </a>
                <a href="orders.php" class="flex items-center space-x-3 p-3 rounded-lg hover:bg-white/10 text-gray-300 hover:text-white transition-colors">
                    <i class="fas fa-history w-5"></i>
                    <span>Sipariş Geçmişi</span>
                </a>
                <a href="add-funds.php" class="flex items-center space-x-3 p-3 rounded-lg hover:bg-white/10 text-gray-300 hover:text-white transition-colors">
                    <i class="fas fa-wallet w-5"></i>
                    <span>Bakiye Yükle</span>
                </a>
                <a href="api.php" class="flex items-center space-x-3 p-3 rounded-lg hover:bg-white/10 text-gray-300 hover:text-white transition-colors">
                    <i class="fas fa-code w-5"></i>
                    <span>API</span>
                </a>
                <a href="support.php" class="flex items-center space-x-3 p-3 rounded-lg hover:bg-white/10 text-gray-300 hover:text-white transition-colors">
                    <i class="fas fa-headset w-5"></i>
                    <span>Destek</span>
                </a>
                <a href="settings.php" class="flex items-center space-x-3 p-3 rounded-lg hover:bg-white/10 text-gray-300 hover:text-white transition-colors">
                    <i class="fas fa-cog w-5"></i>
                    <span>Ayarlar</span>
                </a>
                <a href="logout.php" class="flex items-center space-x-3 p-3 rounded-lg hover:bg-white/10 text-red-400 hover:text-red-300 transition-colors">
                    <i class="fas fa-sign-out-alt w-5"></i>
                    <span>Çıkış Yap</span>
                </a>
            </nav>
        </div>
    </aside>

    <!-- Ana İçerik -->
    <main class="ml-[280px] relative min-h-screen">
        <div class="container mx-auto px-6 py-8">
            <!-- Başlık -->
            <div class="text-center mb-12" data-aos="fade-up">
                <h1 class="text-4xl font-bold text-white mb-4">
                    Sosyal Medya <span class="text-gradient">Servislerimiz</span>
                </h1>
                <p class="text-gray-400">Tüm sosyal medya platformları için en kaliteli ve en hızlı servisler.</p>
            </div>

            <!-- Kategoriler ve Servisler -->
            <?php foreach ($categories as $category): ?>
            <div class="mb-12" data-aos="fade-up">
                <h2 class="text-2xl font-bold text-white mb-6 flex items-center">
                    <i class="<?= htmlspecialchars($category['icon']) ?> mr-3"></i>
                    <?= htmlspecialchars($category['name']) ?>
                </h2>
                
                <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <?php foreach ($services[$category['id']] as $service): ?>
                    <div class="blur-backdrop p-6 rounded-2xl card-hover">
                        <h3 class="text-xl font-bold text-white mb-4"><?= htmlspecialchars($service['name']) ?></h3>
                        <p class="text-gray-400 mb-6"><?= htmlspecialchars($service['description']) ?></p>
                        
                        <div class="space-y-3 text-sm text-gray-300 mb-6">
                            <div class="flex justify-between">
                                <span>Minimum Sipariş:</span>
                                <span><?= number_format($service['min_amount']) ?></span>
                            </div>
                            <div class="flex justify-between">
                                <span>Maksimum Sipariş:</span>
                                <span><?= number_format($service['max_amount']) ?></span>
                            </div>
                            <div class="flex justify-between">
                                <span>Fiyat (1000 adet):</span>
                                <span><?= number_format($service['price'], 2) ?> ₺</span>
                            </div>
                        </div>

                        <a href="new-order.php?service=<?= $service['id'] ?>" 
                           class="block w-full text-center py-3 rounded-lg bg-gradient-to-r from-blue-500 to-purple-600 text-white hover:opacity-90 transition-opacity">
                            Sipariş Ver
                        </a>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
    </main>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
    <script>
        // AOS Animasyon Kütüphanesi Başlatma
        AOS.init({
            duration: 1000,
            once: true
        });

        // Mobil Menü Kontrolü
        document.getElementById('mobileMenuButton')?.addEventListener('click', function() {
            document.querySelector('.sidebar').classList.toggle('active');
        });

        // Animasyonlu blob efekti için
        const style = document.createElement('style');
        style.textContent = `
            @keyframes blob {
                0% { transform: translate(0px, 0px) scale(1); }
                33% { transform: translate(30px, -50px) scale(1.1); }
                66% { transform: translate(-20px, 20px) scale(0.9); }
                100% { transform: translate(0px, 0px) scale(1); }
            }
            .animate-blob {
                animation: blob 7s infinite;
            }
            .animation-delay-2000 {
                animation-delay: 2s;
            }
        `;
        document.head.appendChild(style);
    </script>
</body>
</html>