<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

require_once 'config/db.php';
$db = $conn;

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Kullanıcı bilgilerini al
try {
    $user_id = $_SESSION['user_id'];
    $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        throw new Exception("Kullanıcı bulunamadı");
    }

    // URL'den servis ID'sini al
    $selected_service_id = isset($_GET['service']) ? (int)$_GET['service'] : null;
    $selected_service = null;
    $selected_category_id = null;

    // Eğer servis ID varsa, servisi ve kategorisini al
    if ($selected_service_id) {
        $stmt = $db->prepare("SELECT s.*, c.id as category_id, c.name as category_name 
                             FROM services s 
                             LEFT JOIN categories c ON s.category_id = c.id 
                             WHERE s.id = ?");
        $stmt->execute([$selected_service_id]);
        $selected_service = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($selected_service) {
            $selected_category_id = $selected_service['category_id'];
        }
    }

    // Kategorileri al
    $stmt = $db->prepare("SELECT * FROM categories WHERE status = 'active' ORDER BY sort_order");
    $stmt->execute();
    $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Tüm servisleri al
    $stmt = $db->prepare("SELECT * FROM services WHERE status = 'active'");
    $stmt->execute();
    $services = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Seçili kategoriye ait servisleri filtrele
    if ($selected_category_id) {
        $category_services = array_filter($services, function($service) use ($selected_category_id) {
            return $service['category_id'] == $selected_category_id;
        });
    }

    // Sipariş işleme
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $service_id = $_POST['service_id'] ?? null;
        $link = $_POST['link'] ?? '';
        $quantity = $_POST['quantity'] ?? 0;

        if (!$service_id) {
            throw new Exception("Lütfen bir servis seçin");
        }

        // Servisi al
        $stmt = $db->prepare("SELECT * FROM services WHERE id = ? AND status = 'active'");
        $stmt->execute([$service_id]);
        $service = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$service) {
            throw new Exception("Geçersiz servis");
        }

        // Miktar kontrolü
        if ($quantity < $service['min_amount'] || $quantity > $service['max_amount']) {
            throw new Exception("Geçersiz miktar");
        }

        // Toplam tutarı hesapla
        $amount = $quantity * $service['price'] / 1000;

        // Bakiye kontrolü
        if ($user['balance'] < $amount) {
            throw new Exception("Yetersiz bakiye");
        }

        // Siparişi kaydet
        $db->beginTransaction();

        try {
            // Bakiyeyi güncelle
            $stmt = $db->prepare("UPDATE users SET balance = balance - ? WHERE id = ?");
            $stmt->execute([$amount, $user_id]);

            // Siparişi ekle
            $stmt = $db->prepare("INSERT INTO orders (user_id, service_id, link, quantity, amount, status) VALUES (?, ?, ?, ?, ?, 'pending')");
            $stmt->execute([$user_id, $service_id, $link, $quantity, $amount]);

            $order_id = $db->lastInsertId();

            // İşlemi kaydet
            $stmt = $db->prepare("INSERT INTO transactions (user_id, type, amount, balance_before, balance_after, description) VALUES (?, 'order', ?, ?, ?, ?)");
            $stmt->execute([
                $user_id,
                $amount,
                $user['balance'],
                $user['balance'] - $amount,
                "Sipariş #" . $order_id
            ]);

            $db->commit();
            $_SESSION['success'] = "Sipariş başarıyla oluşturuldu!";
            header("Location: orders.php");
            exit();
        } catch (Exception $e) {
            $db->rollBack();
            throw $e;
        }
    }

} catch (Exception $e) {
    $error = $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NextGen SMM Panel - Yeni Sipariş</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css" />
    <style>
        .neo-gradient {
            background: linear-gradient(120deg, #2E3192, #1BFFFF);
        }
        .card-hover {
            transition: all 0.3s ease;
        }
        .card-hover:hover {
            transform: translateY(-10px);
            box-shadow: 0 20px 40px rgba(0,0,0,0.2);
        }
        .text-gradient {
            background: linear-gradient(to right, #1BFFFF, #2E3192);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .blur-backdrop {
            backdrop-filter: blur(20px);
            background: rgba(255, 255, 255, 0.05);
        }
        .mobile-menu {
            transition: all 0.3s ease;
        }
        .sidebar {
            width: 280px;
            transition: all 0.3s ease;
        }
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }
            .sidebar.active {
                transform: translateX(0);
            }
        }
        @keyframes blob {
            0% { transform: translate(0px, 0px) scale(1); }
            33% { transform: translate(30px, -50px) scale(1.1); }
            66% { transform: translate(-20px, 20px) scale(0.9); }
            100% { transform: translate(0px, 0px) scale(1); }
        }
        .animate-blob {
            animation: blob 7s infinite;
        }
        .animation-delay-2000 {
            animation-delay: 2s;
        }
    </style>
</head>
<body class="bg-[#0A0A1B] min-h-screen">
    <!-- Animasyonlu Arka Plan -->
    <div class="fixed inset-0 opacity-30">
        <div class="absolute inset-0 neo-gradient opacity-20"></div>
        <div class="absolute top-0 left-0 w-96 h-96 bg-blue-500 rounded-full mix-blend-multiply filter blur-3xl animate-blob"></div>
        <div class="absolute top-0 right-0 w-96 h-96 bg-purple-500 rounded-full mix-blend-multiply filter blur-3xl animate-blob animation-delay-2000"></div>
    </div>

    <!-- Sol Sidebar -->
    <aside class="sidebar fixed left-0 top-0 h-full blur-backdrop z-50">
        <div class="p-6">
            <div class="text-2xl font-bold text-gradient mb-8">NEXTGEN SMM</div>
            
            <!-- Kullanıcı Profili -->
            <div class="mb-8 text-center">
                <div class="w-20 h-20 rounded-full bg-gradient-to-r from-blue-500 to-purple-600 mx-auto mb-3 flex items-center justify-center">
                    <i class="fas fa-user text-white text-2xl"></i>
                </div>
                <div class="text-white font-medium"><?php echo htmlspecialchars($user['username']); ?></div>
                <div class="text-sm text-gray-400"><?php echo htmlspecialchars($user['email']); ?></div>
            </div>

            <!-- Menü -->
            <nav class="space-y-2">
                <a href="dashboard.php" class="flex items-center space-x-3 p-3 rounded-lg hover:bg-white/10 text-gray-300 hover:text-white transition-colors">
                    <i class="fas fa-home w-5"></i>
                    <span>Ana Sayfa</span>
                </a>
                <a href="services.php" class="flex items-center space-x-3 p-3 rounded-lg hover:bg-white/10 text-gray-300 hover:text-white transition-colors">
                    <i class="fas fa-list w-5"></i>
                    <span>Servisler</span>
                </a>
                <a href="new-order.php" class="flex items-center space-x-3 p-3 rounded-lg bg-white/10 text-white">
                    <i class="fas fa-shopping-cart w-5"></i>
                    <span>Yeni Sipariş</span>
                </a>
                <a href="orders.php" class="flex items-center space-x-3 p-3 rounded-lg hover:bg-white/10 text-gray-300 hover:text-white transition-colors">
                    <i class="fas fa-history w-5"></i>
                    <span>Sipariş Geçmişi</span>
                </a>
                <a href="add-funds.php" class="flex items-center space-x-3 p-3 rounded-lg hover:bg-white/10 text-gray-300 hover:text-white transition-colors">
                    <i class="fas fa-wallet w-5"></i>
                    <span>Bakiye Yükle</span>
                </a>
                <a href="api.php" class="flex items-center space-x-3 p-3 rounded-lg hover:bg-white/10 text-gray-300 hover:text-white transition-colors">
                    <i class="fas fa-code w-5"></i>
                    <span>API</span>
                </a>
                <a href="support.php" class="flex items-center space-x-3 p-3 rounded-lg hover:bg-white/10 text-gray-300 hover:text-white transition-colors">
                    <i class="fas fa-headset w-5"></i>
                    <span>Destek</span>
                </a>
                <a href="settings.php" class="flex items-center space-x-3 p-3 rounded-lg hover:bg-white/10 text-gray-300 hover:text-white transition-colors">
                    <i class="fas fa-cog w-5"></i>
                    <span>Ayarlar</span>
                </a>
                <a href="logout.php" class="flex items-center space-x-3 p-3 rounded-lg hover:bg-white/10 text-red-400 hover:text-red-300 transition-colors">
                    <i class="fas fa-sign-out-alt w-5"></i>
                    <span>Çıkış Yap</span>
                </a>
            </nav>
        </div>
    </aside>
        <!-- Ana İçerik -->
    <main class="ml-[280px] relative min-h-screen">
        <div class="container mx-auto px-6 py-8">
            <!-- Başlık -->
            <div class="text-center mb-12" data-aos="fade-up">
                <h1 class="text-4xl font-bold text-white mb-4">Yeni Sipariş Oluştur</h1>
                <p class="text-gray-400">Hızlı ve güvenli bir şekilde sipariş verin.</p>
            </div>

            <!-- Sipariş Formu -->
            <div class="max-w-2xl mx-auto">
                <div class="blur-backdrop p-8 rounded-2xl" data-aos="fade-up">
                    <?php if (isset($error)): ?>
                        <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-6">
                            <?php echo htmlspecialchars($error); ?>
                        </div>
                    <?php endif; ?>

                    <form method="POST" action="" class="space-y-6">
                        <!-- Kategori Seçimi -->
                        <div>
                            <label class="block text-gray-300 mb-2">Kategori</label>
                            <select id="category" class="w-full bg-gray-900 border border-gray-700 text-white rounded-lg p-3">
                                <option value="">Kategori Seçin</option>
                                <?php foreach ($categories as $category): ?>
                                    <option value="<?php echo $category['id']; ?>" 
                                        <?php echo ($selected_category_id == $category['id']) ? 'selected' : ''; ?>>
                                        <?php echo htmlspecialchars($category['name']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <!-- Servis Seçimi -->
                        <div>
                            <label class="block text-gray-300 mb-2">Servis</label>
                            <select name="service_id" id="service" class="w-full bg-gray-900 border border-gray-700 text-white rounded-lg p-3" required>
                                <option value="">Önce Kategori Seçin</option>
                                <?php if ($selected_service): ?>
                                    <option value="<?php echo $selected_service['id']; ?>" 
                                        data-price="<?php echo $selected_service['price']; ?>"
                                        data-min="<?php echo $selected_service['min_amount']; ?>"
                                        data-max="<?php echo $selected_service['max_amount']; ?>"
                                        selected>
                                        <?php echo htmlspecialchars($selected_service['name']); ?>
                                    </option>
                                <?php endif; ?>
                            </select>
                        </div>

                        <!-- Link -->
                        <div>
                            <label class="block text-gray-300 mb-2">Link</label>
                            <input type="url" name="link" class="w-full bg-gray-900 border border-gray-700 text-white rounded-lg p-3" required>
                        </div>

                        <!-- Miktar -->
                        <div>
                            <label class="block text-gray-300 mb-2">Miktar</label>
                            <input type="number" name="quantity" id="quantity" class="w-full bg-gray-900 border border-gray-700 text-white rounded-lg p-3" required>
                            <div class="text-sm text-gray-400 mt-1">
                                Min: <span id="min-amount">0</span> - Max: <span id="max-amount">0</span>
                            </div>
                        </div>

                        <!-- Tutar -->
                        <div>
                            <label class="block text-gray-300 mb-2">Toplam Tutar</label>
                            <div class="text-2xl font-bold text-white" id="total-amount">₺0.00</div>
                            <div class="text-sm text-gray-400 mt-1">Mevcut Bakiye: ₺<?php echo number_format($user['balance'], 2); ?></div>
                        </div>

                        <!-- Gönder Butonu -->
                        <button type="submit" class="w-full bg-gradient-to-r from-blue-500 to-purple-600 text-white py-3 px-6 rounded-lg hover:opacity-90 transition-opacity">
                            Siparişi Oluştur
                        </button>
                    </form>
                </div>
            </div>
        </div>
    </main>

    <footer class="ml-[280px] container mx-auto px-6 py-12 text-center text-gray-400">
        <p>&copy; <?= date('Y') ?> NextGen SMM. Tüm hakları saklıdır.</p>
    </footer>

    <script>
        // Servis verilerini JavaScript'e aktar
        const services = <?php echo json_encode($services); ?>;
        const selectedServiceId = <?php echo $selected_service_id ?? 'null'; ?>;
        const selectedCategoryId = <?php echo $selected_category_id ?? 'null'; ?>;

        // Sayfa yüklendiğinde kategori ve servis seçimlerini yap
        document.addEventListener('DOMContentLoaded', function() {
            if (selectedCategoryId) {
                // Kategoriyi seç
                const categorySelect = document.getElementById('category');
                categorySelect.value = selectedCategoryId;

                // Servisleri yükle
                loadServices(selectedCategoryId);

                // Seçili servisi ayarla ve değerleri güncelle
                if (selectedServiceId) {
                    const selectedService = services.find(s => s.id == selectedServiceId);
                    if (selectedService) {
                        document.getElementById('min-amount').textContent = selectedService.min_amount;
                        document.getElementById('max-amount').textContent = selectedService.max_amount;
                        updateTotal();
                    }
                }
            }
        });

        // Servisleri yükle fonksiyonu
        function loadServices(categoryId) {
            const serviceSelect = document.getElementById('service');
            serviceSelect.innerHTML = '<option value="">Servis Seçin</option>';
            
            const filteredServices = services.filter(service => service.category_id == categoryId);
            filteredServices.forEach(service => {
                const selected = service.id == selectedServiceId ? 'selected' : '';
                serviceSelect.innerHTML += `<option value="${service.id}" 
                    data-price="${service.price}"
                    data-min="${service.min_amount}"
                    data-max="${service.max_amount}"
                    ${selected}>
                    ${service.name}
                </option>`;
            });
        }

        // Kategori değiştiğinde servisleri güncelle
        document.getElementById('category').addEventListener('change', function() {
            loadServices(this.value);
        });

        // Servis seçildiğinde min/max değerleri güncelle
        document.getElementById('service').addEventListener('change', function() {
            const option = this.options[this.selectedIndex];
            document.getElementById('min-amount').textContent = option.dataset.min || 0;
            document.getElementById('max-amount').textContent = option.dataset.max || 0;
            updateTotal();
        });

        // Miktar değiştiğinde toplam tutarı güncelle
        document.getElementById('quantity').addEventListener('input', updateTotal);

        function updateTotal() {
            const serviceSelect = document.getElementById('service');
            const quantity = document.getElementById('quantity').value;
            const option = serviceSelect.options[serviceSelect.selectedIndex];
            
            if (option && option.dataset.price) {
                const price = parseFloat(option.dataset.price);
                const total = (price * quantity / 1000).toFixed(2);
                document.getElementById('total-amount').textContent = `₺${total}`;
            }
        }
    </script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
    <script>
        AOS.init({
            duration: 1000,
            once: true
        });
    </script>
</body>
</html>