<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
require_once 'config/db.php';
$db = $conn;

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Kullanıcı bilgilerini al
try {
    $user_id = $_SESSION['user_id'];
    $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        throw new Exception("Kullanıcı bulunamadı");
    }

    // Yeni destek talebi oluşturma
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
        if ($_POST['action'] === 'create_ticket') {
            $subject = trim($_POST['subject']);
            $message = trim($_POST['message']);
            $priority = $_POST['priority'];

            if (empty($subject) || empty($message)) {
                $error = "Lütfen tüm alanları doldurun.";
            } else {
                $stmt = $db->prepare("INSERT INTO tickets (user_id, subject, message, priority) VALUES (?, ?, ?, ?)");
                $stmt->execute([$user_id, $subject, $message, $priority]);
                $success = "Destek talebiniz başarıyla oluşturuldu.";
                header("Location: support.php");
                exit();
            }
        } elseif ($_POST['action'] === 'reply') {
            $ticket_id = $_POST['ticket_id'];
            $message = trim($_POST['message']);

            if (empty($message)) {
                $error = "Lütfen mesajınızı yazın.";
            } else {
                $stmt = $db->prepare("INSERT INTO ticket_replies (ticket_id, user_id, message) VALUES (?, ?, ?)");
                $stmt->execute([$ticket_id, $user_id, $message]);
                
                // Ticket durumunu güncelle
                $stmt = $db->prepare("UPDATE tickets SET status = 'answered' WHERE id = ?");
                $stmt->execute([$ticket_id]);
                
                $success = "Yanıtınız başarıyla gönderildi.";
                header("Location: support.php");
                exit();
            }
        } elseif ($_POST['action'] === 'update_status') {
            $ticket_id = $_POST['ticket_id'];
            $new_status = $_POST['status'];
            
            $stmt = $db->prepare("UPDATE tickets SET status = ? WHERE id = ? AND user_id = ?");
            $stmt->execute([$new_status, $ticket_id, $user_id]);
            $success = "Destek talebi durumu güncellendi.";
            header("Location: support.php");
            exit();
        }
    }

    // Destek taleplerini al
    $stmt = $db->prepare("
        SELECT t.*, 
               COUNT(tr.id) as reply_count 
        FROM tickets t 
        LEFT JOIN ticket_replies tr ON t.id = tr.ticket_id 
        WHERE t.user_id = ? 
        GROUP BY t.id 
        ORDER BY t.created_at DESC
    ");
    $stmt->execute([$user_id]);
    $tickets = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (Exception $e) {
    die("Bir hata oluştu: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Destek Sistemi - NextGen SMM Panel</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css" />
    <style>
        .neo-gradient {
            background: linear-gradient(120deg, #2E3192, #1BFFFF);
        }
        .card-hover {
            transition: all 0.3s ease;
        }
        .card-hover:hover {
            transform: translateY(-10px);
            box-shadow: 0 20px 40px rgba(0,0,0,0.2);
        }
        .text-gradient {
            background: linear-gradient(to right, #1BFFFF, #2E3192);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .blur-backdrop {
            backdrop-filter: blur(20px);
            background: rgba(255, 255, 255, 0.05);
        }
        .mobile-menu {
            transition: all 0.3s ease;
        }
        .sidebar {
            width: 280px;
            transition: all 0.3s ease;
        }
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }
            .sidebar.active {
                transform: translateX(0);
            }
        }
    </style>
</head>
<body class="bg-[#0A0A1B] min-h-screen">
    <!-- Animasyonlu Arka Plan -->
    <div class="fixed inset-0 opacity-30">
        <div class="absolute inset-0 neo-gradient opacity-20"></div>
        <div class="absolute top-0 left-0 w-96 h-96 bg-blue-500 rounded-full mix-blend-multiply filter blur-3xl animate-blob"></div>
        <div class="absolute top-0 right-0 w-96 h-96 bg-purple-500 rounded-full mix-blend-multiply filter blur-3xl animate-blob animation-delay-2000"></div>
    </div>

    <!-- Sol Sidebar -->
    <aside class="sidebar fixed left-0 top-0 h-full blur-backdrop z-50">
        <div class="p-6">
            <div class="text-2xl font-bold text-gradient mb-8">NEXTGEN SMM</div>
            
            <!-- Kullanıcı Profili -->
            <div class="mb-8 text-center">
                <div class="w-20 h-20 rounded-full bg-gradient-to-r from-blue-500 to-purple-600 mx-auto mb-3 flex items-center justify-center">
                    <i class="fas fa-user text-white text-2xl"></i>
                </div>
                <div class="text-white font-medium"><?php echo htmlspecialchars($user['username']); ?></div>
                <div class="text-sm text-gray-400"><?php echo htmlspecialchars($user['email']); ?></div>
            </div>

            <!-- Menü -->
            <nav class="space-y-2">
                <a href="dashboard.php" class="flex items-center space-x-3 p-3 rounded-lg hover:bg-white/10 text-gray-300 hover:text-white transition-colors">
                    <i class="fas fa-home w-5"></i>
                    <span>Ana Sayfa</span>
                </a>
                <a href="services.php" class="flex items-center space-x-3 p-3 rounded-lg hover:bg-white/10 text-gray-300 hover:text-white transition-colors">
                    <i class="fas fa-list w-5"></i>
                    <span>Servisler</span>
                </a>
                <a href="new-order.php" class="flex items-center space-x-3 p-3 rounded-lg hover:bg-white/10 text-gray-300 hover:text-white transition-colors">
                    <i class="fas fa-shopping-cart w-5"></i>
                    <span>Yeni Sipariş</span>
                </a>
                <a href="orders.php" class="flex items-center space-x-3 p-3 rounded-lg hover:bg-white/10 text-gray-300 hover:text-white transition-colors">
                    <i class="fas fa-history w-5"></i>
                    <span>Sipariş Geçmişi</span>
                </a>
                <a href="add-funds.php" class="flex items-center space-x-3 p-3 rounded-lg hover:bg-white/10 text-gray-300 hover:text-white transition-colors">
                    <i class="fas fa-wallet w-5"></i>
                    <span>Bakiye Yükle</span>
                </a>
                <a href="api.php" class="flex items-center space-x-3 p-3 rounded-lg hover:bg-white/10 text-gray-300 hover:text-white transition-colors">
                    <i class="fas fa-code w-5"></i>
                    <span>API</span>
                </a>
                <a href="support.php" class="flex items-center space-x-3 p-3 rounded-lg bg-white/10 text-white">
                    <i class="fas fa-headset w-5"></i>
                    <span>Destek</span>
                </a>
                <a href="settings.php" class="flex items-center space-x-3 p-3 rounded-lg hover:bg-white/10 text-gray-300 hover:text-white transition-colors">
                    <i class="fas fa-cog w-5"></i>
                    <span>Ayarlar</span>
                </a>
                <a href="logout.php" class="flex items-center space-x-3 p-3 rounded-lg hover:bg-white/10 text-red-400 hover:text-red-300 transition-colors">
                    <i class="fas fa-sign-out-alt w-5"></i>
                    <span>Çıkış Yap</span>
                </a>
            </nav>
        </div>
    </aside>

    <!-- Ana İçerik -->
    <main class="ml-[280px] relative min-h-screen">
        <div class="container mx-auto px-6 py-8">
            <!-- Başlık -->
            <div class="text-center mb-12" data-aos="fade-up">
                <h1 class="text-4xl font-bold text-white mb-4">Destek Sistemi</h1>
                <p class="text-gray-400">Sorularınız için bizimle iletişime geçebilirsiniz.</p>
            </div>

            <?php if (isset($success)): ?>
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-6" role="alert">
                    <span class="block sm:inline"><?php echo $success; ?></span>
                </div>
            <?php endif; ?>

            <?php if (isset($error)): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-6" role="alert">
                    <span class="block sm:inline"><?php echo $error; ?></span>
                </div>
            <?php endif; ?>

            <!-- Yeni Destek Talebi Oluştur -->
            <div class="blur-backdrop rounded-2xl p-6 mb-8" data-aos="fade-up">
                <h2 class="text-xl font-semibold text-white mb-4">Yeni Destek Talebi Oluştur</h2>
                <form action="" method="POST">
                    <input type="hidden" name="action" value="create_ticket">
                    <div class="grid grid-cols-1 gap-6">
                        <div>
                            <label class="block text-gray-400 mb-2">Konu</label>
                            <input type="text" name="subject" class="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-blue-500" required>
                        </div>
                        <div>
                            <label class="block text-gray-400 mb-2">Öncelik</label>
                            <select name="priority" class="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-blue-500">
                                <option value="low">Düşük</option>
                                <option value="medium" selected>Orta</option>
                                <option value="high">Yüksek</option>
                            </select>
                        </div>
                        <div>
                            <label class="block text-gray-400 mb-2">Mesaj</label>
                            <textarea name="message" rows="4" class="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-blue-500" required></textarea>
                        </div>
                        <div>
                            <button type="submit" class="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-6 py-2 rounded-lg hover:opacity-90 transition-opacity">
                                Talebi Oluştur
                            </button>
                        </div>
                    </div>
                </form>
            </div>

            <!-- Destek Talepleri Listesi -->
            <div class="blur-backdrop rounded-2xl" data-aos="fade-up">
                <div class="p-6 border-b border-gray-800">
                    <h2 class="text-xl font-semibold text-white">Destek Taleplerim</h2>
                </div>
                <div class="overflow-x-auto">
                    <table class="w-full">
                        <thead>
                            <tr class="text-gray-400 text-left">
                                <th class="px-6 py-3 text-xs font-medium">#</th>
                                <th class="px-6 py-3 text-xs font-medium">Konu</th>
                                <th class="px-6 py-3 text-xs font-medium">Öncelik</th>
                                <th class="px-6 py-3 text-xs font-medium">Durum</th>
                                <th class="px-6 py-3 text-xs font-medium">Yanıtlar</th>
                                <th class="px-6 py-3 text-xs font-medium">Tarih</th>
                                <th class="px-6 py-3 text-xs font-medium">İşlemler</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-800">
                            <?php foreach ($tickets as $ticket): ?>
                            <tr class="text-gray-300 hover:bg-gray-800/50">
                                <td class="px-6 py-4 text-sm">#<?php echo $ticket['id']; ?></td>
                                <td class="px-6 py-4 text-sm"><?php echo htmlspecialchars($ticket['subject']); ?></td>
                                <td class="px-6 py-4">
                                    <?php
                                    $priority_class = [
                                        'low' => 'bg-gray-100 text-gray-800',
                                        'medium' => 'bg-yellow-100 text-yellow-800',
                                        'high' => 'bg-red-100 text-red-800'
                                    ][$ticket['priority']];
                                    ?>
                                    <span class="px-3 py-1 text-xs rounded-full <?php echo $priority_class; ?>">
                                        <?php echo ucfirst($ticket['priority']); ?>
                                    </span>
                                </td>
                                <td class="px-6 py-4">
                                    <?php
                                    $status_class = [
                                        'open' => 'bg-green-100 text-green-800',
                                        'answered' => 'bg-blue-100 text-blue-800',
                                        'closed' => 'bg-gray-100 text-gray-800'
                                    ][$ticket['status']];
                                    ?>
                                    <span class="px-3 py-1 text-xs rounded-full <?php echo $status_class; ?>">
                                        <?php echo ucfirst($ticket['status']); ?>
                                    </span>
                                </td>
                                <td class="px-6 py-4 text-sm"><?php echo $ticket['reply_count']; ?></td>
                                <td class="px-6 py-4 text-sm"><?php echo date('d.m.Y H:i', strtotime($ticket['created_at'])); ?></td>
                                <td class="px-6 py-4 text-sm">
                                    <div class="flex space-x-2">
                                        <button onclick="showTicketDetails(<?php echo $ticket['id']; ?>)" class="text-blue-400 hover:text-blue-300">
                                            <i class="fas fa-eye"></i>
                                        </button>
                                        <?php if ($ticket['status'] !== 'closed'): ?>
                                        <form action="" method="POST" class="inline">
                                            <input type="hidden" name="action" value="update_status">
                                            <input type="hidden" name="ticket_id" value="<?php echo $ticket['id']; ?>">
                                            <input type="hidden" name="status" value="closed">
                                            <button type="submit" class="text-red-400 hover:text-red-300">
                                                <i class="fas fa-times-circle"></i>
                                            </button>
                                        </form>
                                        <?php else: ?>
                                        <form action="" method="POST" class="inline">
                                            <input type="hidden" name="action" value="update_status">
                                            <input type="hidden" name="ticket_id" value="<?php echo $ticket['id']; ?>">
                                            <input type="hidden" name="status" value="open">
                                            <button type="submit" class="text-green-400 hover:text-green-300">
                                                <i class="fas fa-redo"></i>
                                            </button>
                                        </form>
                                        <?php endif; ?>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </main>

    <!-- Ticket Detay Modal -->
    <div id="ticketModal" class="fixed inset-0 bg-black bg-opacity-50 z-50 hidden">
        <div class="container mx-auto px-4 h-full flex items-center justify-center">
            <div class="blur-backdrop rounded-2xl w-full max-w-3xl">
                <div class="p-6 border-b border-gray-800 flex justify-between items-center">
                    <h3 class="text-xl font-semibold text-white">Destek Talebi Detayı</h3>
                    <button onclick="closeTicketModal()" class="text-gray-400 hover:text-white">
                        <i class="fas fa-times"></i>
                    </button>
                </div>
                <div id="ticketContent" class="p-6">
                    <!-- AJAX ile yüklenecek içerik -->
                </div>
            </div>
        </div>
    </div>

    <script>
        function showTicketDetails(ticketId) {
            const modal = document.getElementById('ticketModal');
            const content = document.getElementById('ticketContent');
            modal.classList.remove('hidden');
            
            // AJAX ile ticket detaylarını yükle
            fetch(`get_ticket_details.php?id=${ticketId}`)
                .then(response => response.text())
                .then(html => {
                    content.innerHTML = html;
                });
        }

        function closeTicketModal() {
            document.getElementById('ticketModal').classList.add('hidden');
        }
    </script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
    <script>
        AOS.init({
            duration: 1000,
            once: true
        });

        // Animasyonlu blob efekti için
        const style = document.createElement('style');
        style.textContent = `
            @keyframes blob {
                0% { transform: translate(0px, 0px) scale(1); }
                33% { transform: translate(30px, -50px) scale(1.1); }
                66% { transform: translate(-20px, 20px) scale(0.9); }
                100% { transform: translate(0px, 0px) scale(1); }
            }
            .animate-blob {
                animation: blob 7s infinite;
            }
            .animation-delay-2000 {
                animation-delay: 2s;
            }
        `;
        document.head.appendChild(style);
    </script>
</body>
</html>