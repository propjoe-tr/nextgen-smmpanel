<?php
// Hata raporlamayı açalım (geliştirme aşamasında)
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

// Veritabanı bağlantısını kontrol et
require_once 'config/db.php';
$db = $conn;
if (!isset($db)) {
    die("Veritabanı bağlantısı kurulamadı!");
}

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Kullanıcı bilgilerini al
try {
    $user_id = $_SESSION['user_id'];
    $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$user) {
        throw new Exception("Kullanıcı bulunamadı");
    }

    // Son siparişleri al
    $stmt = $db->prepare("SELECT orders.*, services.name as service_name 
                         FROM orders 
                         LEFT JOIN services ON orders.service_id = services.id 
                         WHERE orders.user_id = ? 
                         ORDER BY orders.created_at DESC LIMIT 5");
    $stmt->execute([$user_id]);
    $recent_orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // İstatistikleri al
    $stmt = $db->prepare("SELECT COUNT(*) FROM orders WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $total_orders = $stmt->fetchColumn();

    $stmt = $db->prepare("SELECT COUNT(*) FROM orders WHERE user_id = ? AND status = 'completed'");
    $stmt->execute([$user_id]);
    $completed_orders = $stmt->fetchColumn();

    $stmt = $db->prepare("SELECT COUNT(*) FROM orders WHERE user_id = ? AND status = 'pending'");
    $stmt->execute([$user_id]);
    $pending_orders = $stmt->fetchColumn();

    $stmt = $db->prepare("SELECT SUM(amount) FROM orders WHERE user_id = ?");
    $stmt->execute([$user_id]);
    $total_spent = $stmt->fetchColumn() ?: 0;

} catch (Exception $e) {
    die("Bir hata oluştu: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NextGen SMM Panel - Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css" />
    <style>
        .neo-gradient {
            background: linear-gradient(120deg, #2E3192, #1BFFFF);
        }
        .card-hover {
            transition: all 0.3s ease;
        }
        .card-hover:hover {
            transform: translateY(-10px);
            box-shadow: 0 20px 40px rgba(0,0,0,0.2);
        }
        .text-gradient {
            background: linear-gradient(to right, #1BFFFF, #2E3192);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .blur-backdrop {
            backdrop-filter: blur(20px);
            background: rgba(255, 255, 255, 0.05);
        }
        .mobile-menu {
            transition: all 0.3s ease;
        }
        .sidebar {
            width: 280px;
            transition: all 0.3s ease;
        }
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }
            .sidebar.active {
                transform: translateX(0);
            }
        }
    </style>
</head>
<body class="bg-[#0A0A1B] min-h-screen">
    <!-- Animasyonlu Arka Plan -->
    <div class="fixed inset-0 opacity-30">
        <div class="absolute inset-0 neo-gradient opacity-20"></div>
        <div class="absolute top-0 left-0 w-96 h-96 bg-blue-500 rounded-full mix-blend-multiply filter blur-3xl animate-blob"></div>
        <div class="absolute top-0 right-0 w-96 h-96 bg-purple-500 rounded-full mix-blend-multiply filter blur-3xl animate-blob animation-delay-2000"></div>
    </div>

    <!-- Sol Sidebar -->
    <aside class="sidebar fixed left-0 top-0 h-full blur-backdrop z-50">
        <div class="p-6">
            <div class="text-2xl font-bold text-gradient mb-8">NEXTGEN SMM</div>
            
            <!-- Kullanıcı Profili -->
            <div class="mb-8 text-center">
                <div class="w-20 h-20 rounded-full bg-gradient-to-r from-blue-500 to-purple-600 mx-auto mb-3 flex items-center justify-center">
                    <i class="fas fa-user text-white text-2xl"></i>
                </div>
                <div class="text-white font-medium"><?php echo htmlspecialchars($user['username']); ?></div>
                <div class="text-sm text-gray-400"><?php echo htmlspecialchars($user['email']); ?></div>
            </div>

            <!-- Menü -->
            <nav class="space-y-2">
                <a href="dashboard.php" class="flex items-center space-x-3 p-3 rounded-lg bg-white/10 text-white">
                    <i class="fas fa-home w-5"></i>
                    <span>Ana Sayfa</span>
                </a>
                <a href="services.php" class="flex items-center space-x-3 p-3 rounded-lg hover:bg-white/10 text-gray-300 hover:text-white transition-colors">
                    <i class="fas fa-list w-5"></i>
                    <span>Servisler</span>
                </a>
                <a href="new-order.php" class="flex items-center space-x-3 p-3 rounded-lg hover:bg-white/10 text-gray-300 hover:text-white transition-colors">
                    <i class="fas fa-shopping-cart w-5"></i>
                    <span>Yeni Sipariş</span>
                </a>
                <a href="orders.php" class="flex items-center space-x-3 p-3 rounded-lg hover:bg-white/10 text-gray-300 hover:text-white transition-colors">
                    <i class="fas fa-history w-5"></i>
                    <span>Sipariş Geçmişi</span>
                </a>
                <a href="add-funds.php" class="flex items-center space-x-3 p-3 rounded-lg hover:bg-white/10 text-gray-300 hover:text-white transition-colors">
                    <i class="fas fa-wallet w-5"></i>
                    <span>Bakiye Yükle</span>
                </a>
                <a href="api.php" class="flex items-center space-x-3 p-3 rounded-lg hover:bg-white/10 text-gray-300 hover:text-white transition-colors">
                    <i class="fas fa-code w-5"></i>
                    <span>API</span>
                </a>
                <a href="support.php" class="flex items-center space-x-3 p-3 rounded-lg hover:bg-white/10 text-gray-300 hover:text-white transition-colors">
                    <i class="fas fa-headset w-5"></i>
                    <span>Destek</span>
                </a>
                <a href="settings.php" class="flex items-center space-x-3 p-3 rounded-lg hover:bg-white/10 text-gray-300 hover:text-white transition-colors">
                    <i class="fas fa-cog w-5"></i>
                    <span>Ayarlar</span>
                </a>
                <a href="logout.php" class="flex items-center space-x-3 p-3 rounded-lg hover:bg-white/10 text-red-400 hover:text-red-300 transition-colors">
                    <i class="fas fa-sign-out-alt w-5"></i>
                    <span>Çıkış Yap</span>
                </a>
            </nav>
        </div>
    </aside>
    <!-- Ana İçerik -->
    <main class="ml-[280px] relative min-h-screen">
        <div class="container mx-auto px-6 py-8">
            <!-- Hoşgeldin Mesajı -->
            <div class="text-center mb-12" data-aos="fade-up">
                <h1 class="text-4xl font-bold text-white mb-4">
                    Hoş Geldin, <span class="text-gradient"><?php echo htmlspecialchars($user['username']); ?></span>
                </h1>
                <p class="text-gray-400">Panel üzerinden tüm işlemlerini kolayca yönetebilirsin.</p>
            </div>

            <!-- İstatistik Kartları -->
            <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
                <div class="blur-backdrop p-6 rounded-2xl card-hover" data-aos="fade-up">
                    <div class="flex items-center">
                        <div class="p-3 rounded-full bg-blue-100 text-blue-600">
                            <i class="fas fa-wallet text-xl"></i>
                        </div>
                        <div class="ml-4">
                            <div class="text-sm text-gray-400">Bakiye</div>
                            <div class="text-xl font-semibold text-white">₺<?php echo number_format($user['balance'], 2); ?></div>
                        </div>
                    </div>
                </div>

                <div class="blur-backdrop p-6 rounded-2xl card-hover" data-aos="fade-up" data-aos-delay="100">
                    <div class="flex items-center">
                        <div class="p-3 rounded-full bg-green-100 text-green-600">
                            <i class="fas fa-check-circle text-xl"></i>
                        </div>
                        <div class="ml-4">
                            <div class="text-sm text-gray-400">Tamamlanan</div>
                            <div class="text-xl font-semibold text-white"><?php echo $completed_orders; ?></div>
                        </div>
                    </div>
                </div>

                <div class="blur-backdrop p-6 rounded-2xl card-hover" data-aos="fade-up" data-aos-delay="200">
                    <div class="flex items-center">
                        <div class="p-3 rounded-full bg-yellow-100 text-yellow-600">
                            <i class="fas fa-clock text-xl"></i>
                        </div>
                        <div class="ml-4">
                            <div class="text-sm text-gray-400">Bekleyen</div>
                            <div class="text-xl font-semibold text-white"><?php echo $pending_orders; ?></div>
                        </div>
                    </div>
                </div>

                <div class="blur-backdrop p-6 rounded-2xl card-hover" data-aos="fade-up" data-aos-delay="300">
                    <div class="flex items-center">
                        <div class="p-3 rounded-full bg-purple-100 text-purple-600">
                            <i class="fas fa-shopping-cart text-xl"></i>
                        </div>
                        <div class="ml-4">
                            <div class="text-sm text-gray-400">Toplam Harcama</div>
                            <div class="text-xl font-semibold text-white">₺<?php echo number_format($total_spent, 2); ?></div>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Son Siparişler -->
            <div class="blur-backdrop rounded-2xl mb-12" data-aos="fade-up">
                <div class="p-6 border-b border-gray-800">
                    <h2 class="text-xl font-semibold text-white">Son Siparişler</h2>
                </div>
                <div class="overflow-x-auto">
                    <table class="w-full">
                        <thead>
                            <tr class="text-gray-400 text-left">
                                <th class="px-6 py-3 text-xs font-medium">Sipariş ID</th>
                                <th class="px-6 py-3 text-xs font-medium">Servis</th>
                                <th class="px-6 py-3 text-xs font-medium">Miktar</th>
                                <th class="px-6 py-3 text-xs font-medium">Tutar</th>
                                <th class="px-6 py-3 text-xs font-medium">Durum</th>
                                <th class="px-6 py-3 text-xs font-medium">Tarih</th>
                            </tr>
                        </thead>
                        <tbody class="divide-y divide-gray-800">
                            <?php foreach ($recent_orders as $order): ?>
                            <tr class="text-gray-300 hover:bg-gray-800/50">
                                <td class="px-6 py-4 text-sm">#<?php echo $order['id']; ?></td>
                                <td class="px-6 py-4 text-sm"><?php echo htmlspecialchars($order['service_name']); ?></td>
                                <td class="px-6 py-4 text-sm"><?php echo number_format($order['quantity']); ?></td>
                                <td class="px-6 py-4 text-sm">₺<?php echo number_format($order['amount'], 2); ?></td>
                                <td class="px-6 py-4">
                                    <?php
                                    $status_class = [
                                        'pending' => 'bg-yellow-100 text-yellow-800',
                                        'processing' => 'bg-blue-100 text-blue-800',
                                        'completed' => 'bg-green-100 text-green-800',
                                        'cancelled' => 'bg-red-100 text-red-800'
                                    ][$order['status']] ?? 'bg-gray-100 text-gray-800';
                                    ?>
                                    <span class="px-3 py-1 text-xs rounded-full <?php echo $status_class; ?>">
                                        <?php echo ucfirst($order['status']); ?>
                                    </span>
                                </td>
                                <td class="px-6 py-4 text-sm text-gray-400">
                                    <?php echo date('d.m.Y H:i', strtotime($order['created_at'])); ?>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <div class="p-4 border-t border-gray-800">
                    <a href="orders.php" class="text-blue-400 hover:text-blue-300 text-sm font-medium">
                        Tüm Siparişleri Görüntüle →
                    </a>
                </div>
            </div>

            <!-- Hızlı İşlemler -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
                <div class="blur-backdrop p-6 rounded-2xl card-hover" data-aos="fade-up">
                    <h3 class="text-xl font-semibold text-white mb-4">Hızlı Sipariş</h3>
                    <p class="text-gray-400 mb-4">Yeni bir sipariş oluşturmak için hemen başlayın.</p>
                    <a href="new-order.php" class="inline-flex items-center justify-center px-6 py-3 rounded-full bg-gradient-to-r from-blue-500 to-purple-600 text-white hover:opacity-90 transition-opacity">
                        Sipariş Oluştur
                    </a>
                </div>

                <div class="blur-backdrop p-6 rounded-2xl card-hover" data-aos="fade-up" data-aos-delay="100">
                    <h3 class="text-xl font-semibold text-white mb-4">Bakiye Yükle</h3>
                    <p class="text-gray-400 mb-4">Hesabınıza hemen bakiye yükleyin.</p>
                    <a href="add-funds.php" class="inline-flex items-center justify-center px-6 py-3 rounded-full bg-gradient-to-r from-green-500 to-blue-600 text-white hover:opacity-90 transition-opacity">
                        Bakiye Yükle
                    </a>
                </div>
            </div>
        </div>
    </main>

    <footer class="ml-[280px] container mx-auto px-6 py-12 text-center text-gray-400">
        <p>&copy; <?= date('Y') ?> NextGen SMM. Tüm hakları saklıdır.</p>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
    <script>
        // AOS Animasyon Kütüphanesi Başlatma
        AOS.init({
            duration: 1000,
            once: true
        });

        // Mobil Menü Kontrolü
        document.getElementById('mobileMenuButton').addEventListener('click', function() {
            document.querySelector('.sidebar').classList.toggle('active');
        });

        // Animasyonlu blob efekti için
        const style = document.createElement('style');
        style.textContent = `
            @keyframes blob {
                0% { transform: translate(0px, 0px) scale(1); }
                33% { transform: translate(30px, -50px) scale(1.1); }
                66% { transform: translate(-20px, 20px) scale(0.9); }
                100% { transform: translate(0px, 0px) scale(1); }
            }
            .animate-blob {
                animation: blob 7s infinite;
            }
            .animation-delay-2000 {
                animation-delay: 2s;
            }
        `;
        document.head.appendChild(style);
    </script>
</body>
</html>