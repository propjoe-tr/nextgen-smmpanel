<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

require_once 'config/db.php';
$db = $conn;

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Kullanıcı bilgilerini al
try {
    $user_id = $_SESSION['user_id'];
    $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    // Banka bilgilerini settings tablosundan al
    $stmt = $db->prepare("SELECT value FROM settings WHERE name = 'bank_details'");
    $stmt->execute();
    $bank_details = $stmt->fetchColumn() ?: 'TR00 0000 0000 0000 0000 0000 00 - Örnek Banka - Firma Adı';

    // Para yatırma talebi gönderildiğinde
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $amount = floatval($_POST['amount']);
        $payment_details = htmlspecialchars($_POST['payment_details']);
        
        if ($amount < 10) {
            $error = "Minimum yatırılabilecek tutar 10 TL'dir.";
        } else {
            try {
                $stmt = $db->prepare("INSERT INTO transactions (user_id, type, amount, balance_before, balance_after, description, status, payment_method, payment_details) VALUES (?, 'deposit', ?, ?, ?, ?, 'pending', 'bank_transfer', ?)");
                
                $balance_before = $user['balance'];
                $balance_after = $balance_before; // Onay beklerken bakiye değişmez
                $description = "Havale/EFT ile bakiye yükleme talebi";
                
                $stmt->execute([$user_id, $amount, $balance_before, $balance_after, $description, $payment_details]);
                
                $success = "Para yatırma talebiniz başarıyla oluşturuldu. İşleminiz onaylandıktan sonra bakiyenize yansıyacaktır.";
            } catch (Exception $e) {
                $error = "İşlem sırasında bir hata oluştu: " . $e->getMessage();
            }
        }
    }

    // Son işlemleri al
    $stmt = $db->prepare("SELECT * FROM transactions WHERE user_id = ? AND type = 'deposit' ORDER BY created_at DESC LIMIT 5");
    $stmt->execute([$user_id]);
    $recent_transactions = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (Exception $e) {
    die("Bir hata oluştu: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bakiye Yükle - NextGen SMM Panel</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css" />
    <style>
        .neo-gradient {
            background: linear-gradient(120deg, #2E3192, #1BFFFF);
        }
        .card-hover {
            transition: all 0.3s ease;
        }
        .card-hover:hover {
            transform: translateY(-10px);
            box-shadow: 0 20px 40px rgba(0,0,0,0.2);
        }
        .text-gradient {
            background: linear-gradient(to right, #1BFFFF, #2E3192);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .blur-backdrop {
            backdrop-filter: blur(20px);
            background: rgba(255, 255, 255, 0.05);
        }
        .mobile-menu {
            transition: all 0.3s ease;
        }
        .sidebar {
            width: 280px;
            transition: all 0.3s ease;
        }
        @media (max-width: 768px) {
            .sidebar {
                transform: translateX(-100%);
            }
            .sidebar.active {
                transform: translateX(0);
            }
        }
        @keyframes blob {
            0% { transform: translate(0px, 0px) scale(1); }
            33% { transform: translate(30px, -50px) scale(1.1); }
            66% { transform: translate(-20px, 20px) scale(0.9); }
            100% { transform: translate(0px, 0px) scale(1); }
        }
        .animate-blob {
            animation: blob 7s infinite;
        }
        .animation-delay-2000 {
            animation-delay: 2s;
        }
    </style>
</head>
<body class="bg-[#0A0A1B] min-h-screen">
    <!-- Animasyonlu Arka Plan -->
    <div class="fixed inset-0 opacity-30">
        <div class="absolute inset-0 neo-gradient opacity-20"></div>
        <div class="absolute top-0 left-0 w-96 h-96 bg-blue-500 rounded-full mix-blend-multiply filter blur-3xl animate-blob"></div>
        <div class="absolute top-0 right-0 w-96 h-96 bg-purple-500 rounded-full mix-blend-multiply filter blur-3xl animate-blob animation-delay-2000"></div>
    </div>

    <!-- Sol Sidebar -->
    <aside class="sidebar fixed left-0 top-0 h-full blur-backdrop z-50">
        <div class="p-6">
            <div class="text-2xl font-bold text-gradient mb-8">NEXTGEN SMM</div>
            
            <!-- Kullanıcı Profili -->
            <div class="mb-8 text-center">
                <div class="w-20 h-20 rounded-full bg-gradient-to-r from-blue-500 to-purple-600 mx-auto mb-3 flex items-center justify-center">
                    <i class="fas fa-user text-white text-2xl"></i>
                </div>
                <div class="text-white font-medium"><?php echo htmlspecialchars($user['username']); ?></div>
                <div class="text-sm text-gray-400"><?php echo htmlspecialchars($user['email']); ?></div>
            </div>

            <!-- Menü -->
            <nav class="space-y-2">
                <a href="dashboard.php" class="flex items-center space-x-3 p-3 rounded-lg hover:bg-white/10 text-gray-300 hover:text-white transition-colors">
                    <i class="fas fa-home w-5"></i>
                    <span>Ana Sayfa</span>
                </a>
                <a href="services.php" class="flex items-center space-x-3 p-3 rounded-lg hover:bg-white/10 text-gray-300 hover:text-white transition-colors">
                    <i class="fas fa-list w-5"></i>
                    <span>Servisler</span>
                </a>
                <a href="new-order.php" class="flex items-center space-x-3 p-3 rounded-lg hover:bg-white/10 text-gray-300 hover:text-white transition-colors">
                    <i class="fas fa-shopping-cart w-5"></i>
                    <span>Yeni Sipariş</span>
                </a>
                <a href="orders.php" class="flex items-center space-x-3 p-3 rounded-lg hover:bg-white/10 text-gray-300 hover:text-white transition-colors">
                    <i class="fas fa-history w-5"></i>
                    <span>Sipariş Geçmişi</span>
                </a>
                <a href="add-funds.php" class="flex items-center space-x-3 p-3 rounded-lg bg-white/10 text-white">
                    <i class="fas fa-wallet w-5"></i>
                    <span>Bakiye Yükle</span>
                </a>
                <a href="api.php" class="flex items-center space-x-3 p-3 rounded-lg hover:bg-white/10 text-gray-300 hover:text-white transition-colors">
                    <i class="fas fa-code w-5"></i>
                    <span>API</span>
                </a>
                <a href="support.php" class="flex items-center space-x-3 p-3 rounded-lg hover:bg-white/10 text-gray-300 hover:text-white transition-colors">
                    <i class="fas fa-headset w-5"></i>
                    <span>Destek</span>
                </a>
                <a href="settings.php" class="flex items-center space-x-3 p-3 rounded-lg hover:bg-white/10 text-gray-300 hover:text-white transition-colors">
                    <i class="fas fa-cog w-5"></i>
                    <span>Ayarlar</span>
                </a>
                <a href="logout.php" class="flex items-center space-x-3 p-3 rounded-lg hover:bg-white/10 text-red-400 hover:text-red-300 transition-colors">
                    <i class="fas fa-sign-out-alt w-5"></i>
                    <span>Çıkış Yap</span>
                </a>
            </nav>
        </div>
    </aside>

    <!-- Ana İçerik -->
    <main class="ml-[280px] relative min-h-screen">
        <div class="container mx-auto px-6 py-8">
            <!-- Başlık -->
            <div class="text-center mb-12" data-aos="fade-up">
                <h1 class="text-4xl font-bold text-white mb-4">Bakiye Yükle</h1>
                <p class="text-gray-400">Hesabınıza güvenli bir şekilde bakiye yükleyin.</p>
            </div>

            <?php if (isset($success)): ?>
            <div class="mb-6 p-4 bg-green-100 border border-green-400 text-green-700 rounded" role="alert">
                <?php echo $success; ?>
            </div>
            <?php endif; ?>

            <?php if (isset($error)): ?>
            <div class="mb-6 p-4 bg-red-100 border border-red-400 text-red-700 rounded" role="alert">
                <?php echo $error; ?>
            </div>
            <?php endif; ?>

            <!-- Banka Bilgileri Kartı -->
            <div class="blur-backdrop rounded-2xl mb-8 p-6" data-aos="fade-up">
                <h2 class="text-xl font-semibold text-white mb-4">Banka Bilgileri</h2>
                <div class="bg-white/5 rounded-lg p-4 mb-4">
                    <p class="text-gray-300 font-mono select-all"><?php echo $bank_details; ?></p>
                </div>
                <p class="text-yellow-400 text-sm">
                    <i class="fas fa-info-circle mr-2"></i>
                    Lütfen açıklama kısmına kullanıcı adınızı yazmayı unutmayın.
                </p>
            </div>

            <!-- Para Yatırma Formu ve Son İşlemler -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
                <!-- Para Yatırma Formu -->
                <div class="blur-backdrop rounded-2xl p-6" data-aos="fade-up">
                    <h2 class="text-xl font-semibold text-white mb-6">Para Yatırma Talebi Oluştur</h2>
                    <form method="POST" action="">
                        <div class="mb-6">
                            <label class="block text-gray-400 mb-2" for="amount">Yatırılacak Tutar (TL)</label>
                            <input type="number" id="amount" name="amount" min="10" step="0.01" required
                                class="w-full bg-white/5 border border-gray-700 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-blue-500">
                            <p class="text-sm text-gray-500 mt-1">Minimum yatırılabilecek tutar: 10 TL</p>
                        </div>
                        <div class="mb-6">
                            <label class="block text-gray-400 mb-2" for="payment_details">Ödeme Detayları</label>
                            <textarea id="payment_details" name="payment_details" required
                                class="w-full bg-white/5 border border-gray-700 rounded-lg px-4 py-3 text-white focus:outline-none focus:border-blue-500"
                                rows="3" placeholder="Gönderen ad-soyad ve varsa açıklama"></textarea>
                        </div>
                        <button type="submit" 
                            class="w-full bg-gradient-to-r from-blue-500 to-purple-600 text-white rounded-lg px-6 py-3 hover:opacity-90 transition-opacity">
                            Talep Oluştur
                        </button>
                    </form>
                </div>

                <!-- Son İşlemler -->
                <div class="blur-backdrop rounded-2xl p-6" data-aos="fade-up" data-aos-delay="100">
                    <h2 class="text-xl font-semibold text-white mb-6">Son İşlemler</h2>
                    <div class="space-y-4">
                        <?php foreach ($recent_transactions as $transaction): ?>
                        <div class="bg-white/5 rounded-lg p-4 flex justify-between items-center">
                            <div>
                                <div class="text-white">₺<?php echo number_format($transaction['amount'], 2); ?></div>
                                <div class="text-sm text-gray-400">
                                    <?php echo date('d.m.Y H:i', strtotime($transaction['created_at'])); ?>
                                </div>
                            </div>
                            <div>
                                <?php
                                $status_class = [
                                    'pending' => 'bg-yellow-100 text-yellow-800',
                                    'completed' => 'bg-green-100 text-green-800',
                                    'cancelled' => 'bg-red-100 text-red-800'
                                ][$transaction['status']] ?? 'bg-gray-100 text-gray-800';
                                
                                $status_text = [
                                    'pending' => 'Bekliyor',
                                    'completed' => 'Tamamlandı',
                                    'cancelled' => 'İptal Edildi'
                                ][$transaction['status']] ?? 'Bilinmiyor';
                                ?>
                                <span class="px-3 py-1 text-xs rounded-full <?php echo $status_class; ?>">
                                    <?php echo $status_text; ?>
                                </span>
                            </div>
                        </div>
                        <?php endforeach; ?>
                        <?php if (empty($recent_transactions)): ?>
                        <div class="text-center text-gray-400 py-4">
                            Henüz işlem bulunmuyor.
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </main>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
    <script>
        AOS.init({
            duration: 1000,
            once: true
        });
    </script>
</body>
</html>