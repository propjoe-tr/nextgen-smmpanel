<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);
require_once 'config/db.php';

if (isset($_POST['register'])) {
    $username = htmlspecialchars($_POST['username'], ENT_QUOTES, 'UTF-8');
    $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
    $password = $_POST['password'];
    $password_confirm = $_POST['password_confirm'];

    $errors = [];

    // Validasyonlar
    if (empty($username)) {
        $errors[] = "Kullanıcı adı gereklidir.";
    }
    if (empty($email)) {
        $errors[] = "E-posta adresi gereklidir.";
    }
    if (empty($password)) {
        $errors[] = "Şifre gereklidir.";
    }
    if ($password !== $password_confirm) {
        $errors[] = "Şifreler eşleşmiyor.";
    }
    if (strlen($password) < 6) {
        $errors[] = "Şifre en az 6 karakter olmalıdır.";
    }
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Geçerli bir e-posta adresi giriniz.";
    }

    // E-posta ve kullanıcı adı kontrolü
    try {
        $check_query = "SELECT * FROM users WHERE email = :email OR username = :username";
        $stmt = $db->prepare($check_query);
        $stmt->execute([
            ':email' => $email,
            ':username' => $username
        ]);

        if ($stmt->rowCount() > 0) {
            $errors[] = "Bu e-posta veya kullanıcı adı zaten kullanımda.";
        }

        if (empty($errors)) {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $insert_query = "INSERT INTO users (username, email, password, created_at) VALUES (:username, :email, :password, NOW())";
            $stmt = $db->prepare($insert_query);
            
            if ($stmt->execute([
                ':username' => $username,
                ':email' => $email,
                ':password' => $hashed_password
            ])) {
                echo "<script>
                        Swal.fire({
                            title: 'Başarılı!',
                            text: 'Kayıt işleminiz başarıyla tamamlandı. Giriş sayfasına yönlendiriliyorsunuz...',
                            icon: 'success',
                            timer: 2000,
                            showConfirmButton: false
                        }).then(function() {
                            window.location.href = 'login.php';
                        });
                      </script>";
                exit;
            } else {
                $errorInfo = $stmt->errorInfo();
                throw new PDOException("Veritabanı hatası: " . $errorInfo[2]);
            }
        } else {
            $error_message = implode('<br>', $errors);
            echo "<script>
                    Swal.fire({
                        title: 'Hata!',
                        html: '{$error_message}',
                        icon: 'error',
                        confirmButtonText: 'Tamam'
                    });
                  </script>";
        }
    } catch (PDOException $e) {
        error_log("PDO Hatası: " . $e->getMessage());
        echo "<script>
                Swal.fire({
                    title: 'Hata!',
                    text: 'Bir hata oluştu. Lütfen daha sonra tekrar deneyin.',
                    icon: 'error',
                    confirmButtonText: 'Tamam'
                });
              </script>";
    }
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kayıt Ol - NextGen SMM Panel</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css" />
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.32/dist/sweetalert2.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.32/dist/sweetalert2.all.min.js"></script>
    
    <style>
        .neo-gradient {
            background: linear-gradient(120deg, #2E3192, #1BFFFF);
        }
        .text-gradient {
            background: linear-gradient(to right, #1BFFFF, #2E3192);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
        .blur-backdrop {
            backdrop-filter: blur(20px);
            background: rgba(255, 255, 255, 0.05);
        }
        .swal2-popup {
            background: rgba(26, 26, 46, 0.95) !important;
            backdrop-filter: blur(10px);
            border: 1px solid rgba(255, 255, 255, 0.1);
        }
        .swal2-title, .swal2-html-container {
            color: #fff !important;
        }
        .swal2-confirm {
            background: linear-gradient(to right, #1BFFFF, #2E3192) !important;
        }
        @keyframes blob {
            0% { transform: translate(0px, 0px) scale(1); }
            33% { transform: translate(30px, -50px) scale(1.1); }
            66% { transform: translate(-20px, 20px) scale(0.9); }
            100% { transform: translate(0px, 0px) scale(1); }
        }
        .animate-blob {
            animation: blob 7s infinite;
        }
        .animation-delay-2000 {
            animation-delay: 2s;
        }
    </style>
</head>
<body class="bg-[#0A0A1B] min-h-screen">
    <!-- Animasyonlu Arka Plan -->
    <div class="fixed inset-0 opacity-30">
        <div class="absolute inset-0 neo-gradient opacity-20"></div>
        <div class="absolute top-0 left-0 w-96 h-96 bg-blue-500 rounded-full mix-blend-multiply filter blur-3xl animate-blob"></div>
        <div class="absolute top-0 right-0 w-96 h-96 bg-purple-500 rounded-full mix-blend-multiply filter blur-3xl animate-blob animation-delay-2000"></div>
    </div>

    <!-- Ana İçerik -->
    <div class="relative min-h-screen flex items-center justify-center p-6">
        <div class="blur-backdrop p-8 rounded-2xl w-full max-w-md" data-aos="fade-up">
            <h1 class="text-3xl font-bold text-white text-center mb-8">
                <span class="text-gradient">NextGen SMM</span><br>
                Kayıt Ol
            </h1>

            <form method="POST" action="" class="space-y-6">
                <div>
                    <label class="block text-gray-300 mb-2" for="username">Kullanıcı Adı</label>
                    <input type="text" id="username" name="username" 
                           class="w-full bg-[#1A1A2E] text-white rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
                           required>
                </div>

                <div>
                    <label class="block text-gray-300 mb-2" for="email">E-posta Adresi</label>
                    <input type="email" id="email" name="email" 
                           class="w-full bg-[#1A1A2E] text-white rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
                           required>
                </div>

                <div>
                    <label class="block text-gray-300 mb-2" for="password">Şifre</label>
                    <input type="password" id="password" name="password" 
                           class="w-full bg-[#1A1A2E] text-white rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
                           required>
                </div>

                <div>
                    <label class="block text-gray-300 mb-2" for="password_confirm">Şifre Tekrar</label>
                    <input type="password" id="password_confirm" name="password_confirm" 
                           class="w-full bg-[#1A1A2E] text-white rounded-lg px-4 py-3 focus:outline-none focus:ring-2 focus:ring-blue-500"
                           required>
                </div>

                <button type="submit" name="register" 
                        class="w-full py-4 rounded-lg bg-gradient-to-r from-blue-500 to-purple-600 text-white font-medium hover:opacity-90 transition-opacity">
                    Kayıt Ol
                </button>

                <p class="text-center text-gray-400">
                    Zaten hesabınız var mı? 
                    <a href="login.php" class="text-blue-400 hover:text-blue-300">Giriş Yap</a>
                </p>
            </form>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
    <script>
        AOS.init({
            duration: 1000,
            once: true
        });
    </script>
</body>
</html>