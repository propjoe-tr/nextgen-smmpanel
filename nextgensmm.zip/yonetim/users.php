<?php
// Çıktı tamponlamasını başlat
ob_start();

// Hata raporlama
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Session başlat
session_start();

// Veritabanı bağlantısı
require_once '../config/db.php';

// Yönetici girişi kontrolü
if(!isset($_SESSION['admin_id'])) {
    header("Location: giris.php");
    exit();
}

// Kullanıcı rolünü veritabanından kontrol et
$admin_check = $conn->prepare("SELECT role FROM users WHERE id = ? AND role = 'admin'");
$admin_check->execute([$_SESSION['admin_id']]);
if(!$admin_check->fetch()) {
    header("Location: giris.php");
    exit();
}

// Kullanıcıları çek
$users = $conn->query("
    SELECT users.*, 
           COALESCE(COUNT(DISTINCT orders.id), 0) as total_orders,
           COALESCE(SUM(orders.amount), 0) as total_spent,
           COALESCE(COUNT(DISTINCT tickets.id), 0) as total_tickets
    FROM users 
    LEFT JOIN orders ON users.id = orders.user_id
    LEFT JOIN tickets ON users.id = tickets.user_id
    WHERE users.role != 'admin'
    GROUP BY users.id, users.username, users.email, users.balance, users.role, 
             users.status, users.created_at
    ORDER BY users.created_at DESC
")->fetchAll();

// Kullanıcı düzenleme işlemi
if(isset($_POST['update_user'])) {
    $user_id = $_POST['user_id'];
    $status = $_POST['status'];
    $role = $_POST['role'];
    $balance = $_POST['balance'];

    try {
        $stmt = $conn->prepare("
            UPDATE users 
            SET status = ?, role = ?, balance = ?, updated_at = NOW()
            WHERE id = ?
        ");
        $stmt->execute([$status, $role, $balance, $user_id]);
        
        header("Location: users.php?success=1");
        exit();
    } catch(PDOException $e) {
        $error = "Güncelleme sırasında bir hata oluştu: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kullanıcı Yönetimi - NextGen SMM Panel</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.2.1/flowbite.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <style>
        .neo-gradient {
            background: linear-gradient(120deg, #2E3192, #1BFFFF);
        }
        .text-gradient {
            background: linear-gradient(to right, #1BFFFF, #2E3192);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
    </style>
</head>
<body class="bg-[#0A0A1B]">

<!-- Sidebar -->
<aside id="logo-sidebar" class="fixed top-0 left-0 z-40 w-64 h-screen transition-transform -translate-x-full sm:translate-x-0" aria-label="Sidebar">
   <div class="h-full px-3 py-4 overflow-y-auto bg-[#12122C]">
      <a href="index.php" class="flex items-center ps-2.5 mb-5">
         <span class="self-center text-xl font-semibold whitespace-nowrap text-white">NextGen <span class="text-gradient">SMM Panel</span></span>
      </a>
      <ul class="space-y-2 font-medium">
         <li>
            <a href="index.php" class="flex items-center p-2 text-white rounded-lg hover:bg-gray-700 group">
               <i class="fas fa-home w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Dashboard</span>
            </a>
         </li>
         <li>
            <a href="users.php" class="flex items-center p-2 text-white rounded-lg hover:bg-gray-700 group">
               <i class="fas fa-users w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Kullanıcılar</span>
            </a>
         </li>
         <li>
            <a href="services.php" class="flex items-center p-2 text-white rounded-lg hover:bg-gray-700 group">
               <i class="fas fa-list w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Servisler</span>
            </a>
         </li>
         <li>
            <a href="orders.php" class="flex items-center p-2 text-white rounded-lg hover:bg-gray-700 group">
               <i class="fas fa-shopping-cart w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Siparişler</span>
            </a>
         </li>
         <li>
            <a href="tickets.php" class="flex items-center p-2 text-white rounded-lg hover:bg-gray-700 group">
               <i class="fas fa-ticket-alt w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Destek Talepleri</span>
            </a>
         </li>
         <li>
            <a href="bank.php" class="flex items-center p-2 text-white rounded-lg bg-gray-700 group">
               <i class="fas fa-credit-card w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Bakiye İşlemleri</span>
            </a>
         </li>
         <li>
            <a href="settings.php" class="flex items-center p-2 text-white rounded-lg hover:bg-gray-700 group">
               <i class="fas fa-cog w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Ayarlar</span>
            </a>
         </li>
         <li>
            <a href="logout.php" class="flex items-center p-2 text-white rounded-lg hover:bg-gray-700 group">
               <i class="fas fa-sign-out-alt w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Çıkış Yap</span>
            </a>
         </li>
      </ul>
   </div>
</aside>

<!-- Ana İçerik -->
<div class="p-4 sm:ml-64">
    <div class="p-4 mt-14">
        <!-- Başlık -->
        <div class="flex justify-between items-center mb-6">
            <h2 class="text-2xl font-bold text-white">Kullanıcı Yönetimi</h2>
            <a href="add-user.php" class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                <i class="fas fa-plus mr-2"></i>Yeni Kullanıcı
            </a>
        </div>

        <?php if(isset($_GET['success'])): ?>
        <div class="p-4 mb-6 text-sm text-green-800 rounded-lg bg-green-50" role="alert">
            Kullanıcı başarıyla güncellendi!
        </div>
        <?php endif; ?>

        <!-- Kullanıcı Tablosu -->
        <div class="overflow-x-auto bg-[#12122C] rounded-lg shadow">
            <table class="w-full text-sm text-left text-gray-400">
                <thead class="text-xs uppercase bg-gray-700 text-gray-400">
                    <tr>
                        <th scope="col" class="px-6 py-3">ID</th>
                        <th scope="col" class="px-6 py-3">Kullanıcı Adı</th>
                        <th scope="col" class="px-6 py-3">E-posta</th>
                        <th scope="col" class="px-6 py-3">Bakiye</th>
                        <th scope="col" class="px-6 py-3">Rol</th>
                        <th scope="col" class="px-6 py-3">Durum</th>
                        <th scope="col" class="px-6 py-3">Siparişler</th>
                        <th scope="col" class="px-6 py-3">Toplam Harcama</th>
                        <th scope="col" class="px-6 py-3">Kayıt Tarihi</th>
                        <th scope="col" class="px-6 py-3">İşlemler</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach($users as $user): ?>
                    <tr class="border-b bg-[#12122C] border-gray-700">
                        <td class="px-6 py-4">#<?= $user['id'] ?></td>
                        <td class="px-6 py-4 font-medium text-white">
                            <?= htmlspecialchars($user['username']) ?>
                        </td>
                        <td class="px-6 py-4"><?= htmlspecialchars($user['email']) ?></td>
                        <td class="px-6 py-4">₺<?= number_format((float)$user['balance'], 2) ?></td>
                        <td class="px-6 py-4">
                            <span class="px-2 py-1 rounded text-xs <?= $user['role'] == 'reseller' ? 'bg-purple-900 text-purple-300' : 'bg-blue-900 text-blue-300' ?>">
                                <?= ucfirst($user['role']) ?>
                            </span>
                        </td>
                        <td class="px-6 py-4">
                            <span class="px-2 py-1 rounded text-xs <?= $user['status'] == 'active' ? 'bg-green-900 text-green-300' : 'bg-red-900 text-red-300' ?>">
                                <?= ucfirst($user['status']) ?>
                            </span>
                        </td>
                        <td class="px-6 py-4"><?= number_format((float)$user['total_orders']) ?></td>
                        <td class="px-6 py-4">₺<?= number_format((float)$user['total_spent'], 2) ?></td>
                        <td class="px-6 py-4"><?= date('d.m.Y', strtotime($user['created_at'])) ?></td>
                        <td class="px-6 py-4">
                            <button onclick="editUser(<?= htmlspecialchars(json_encode($user)) ?>)" class="text-blue-500 hover:text-blue-400 mr-3">
                                <i class="fas fa-edit"></i>
                            </button>
                            <a href="user-details.php?id=<?= $user['id'] ?>" class="text-green-500 hover:text-green-400">
                                <i class="fas fa-eye"></i>
                            </a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Düzenleme Modal -->
<div id="editModal" tabindex="-1" aria-hidden="true" class="fixed top-0 left-0 right-0 z-50 hidden w-full p-4 overflow-x-hidden overflow-y-auto md:inset-0 h-[calc(100%-1rem)] max-h-full">
    <div class="relative w-full max-w-md max-h-full">
        <div class="relative bg-[#12122C] rounded-lg shadow">
            <div class="flex items-start justify-between p-4 border-b border-gray-700">
                <h3 class="text-xl font-semibold text-white">
                    Kullanıcı Düzenle
                </h3>
                <button type="button" class="text-gray-400 bg-transparent hover:bg-gray-700 rounded-lg text-sm w-8 h-8 ml-auto inline-flex justify-center items-center" data-modal-hide="editModal">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <form method="POST" class="p-6">
                <input type="hidden" name="user_id" id="edit_user_id">
                
                <div class="mb-4">
                    <label class="block mb-2 text-sm font-medium text-white">Kullanıcı Adı</label>
                    <input type="text" id="edit_username" class="bg-gray-700 border border-gray-600 text-white text-sm rounded-lg block w-full p-2.5" disabled>
                </div>
                
                <div class="mb-4">
                    <label class="block mb-2 text-sm font-medium text-white">Bakiye</label>
                    <input type="number" step="0.01" name="balance" id="edit_balance" class="bg-gray-700 border border-gray-600 text-white text-sm rounded-lg block w-full p-2.5">
                </div>
                
                <div class="mb-4">
                    <label class="block mb-2 text-sm font-medium text-white">Rol</label>
                    <select name="role" id="edit_role" class="bg-gray-700 border border-gray-600 text-white text-sm rounded-lg block w-full p-2.5">
                        <option value="user">User</option>
                        <option value="reseller">Reseller</option>
                    </select>
                </div>
                
                <div class="mb-4">
                    <label class="block mb-2 text-sm font-medium text-white">Durum</label>
                    <select name="status" id="edit_status" class="bg-gray-700 border border-gray-600 text-white text-sm rounded-lg block w-full p-2.5">
                        <option value="active">Active</option>
                        <option value="suspended">Suspended</option>
                        <option value="banned">Banned</option>
                    </select>
                </div>
                
                <button type="submit" name="update_user" class="w-full text-white bg-blue-600 hover:bg-blue-700 font-medium rounded-lg text-sm px-5 py-2.5 text-center">
                    Güncelle
                </button>
            </form>
        </div>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.2.1/flowbite.min.js"></script>
<script>
function editUser(user) {
    document.getElementById('edit_user_id').value = user.id;
    document.getElementById('edit_username').value = user.username;
    document.getElementById('edit_balance').value = user.balance;
    document.getElementById('edit_role').value = user.role;
    document.getElementById('edit_status').value = user.status;
    
    const modal = new Modal(document.getElementById('editModal'));
    modal.show();
}
</script>
</body>
</html>
<?php
// Çıktı tamponlamasını sonlandır
ob_end_flush();
?>