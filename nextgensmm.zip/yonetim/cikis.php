<?php
session_start();

// Tüm session verilerini temizle
session_unset();
session_destroy();

// SweetAlert2 ile başarılı çıkış mesajı göster ve yönlendir
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <title>Çıkış Yapılıyor...</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.32/dist/sweetalert2.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.7.32/dist/sweetalert2.all.min.js"></script>
</head>
<body>
    <script>
        Swal.fire({
            title: 'Başarılı!',
            text: 'Güvenli çıkış yapıldı. Yönlendiriliyorsunuz...',
            icon: 'success',
            timer: 2000,
            showConfirmButton: false
        }).then(function() {
            window.location.href = 'giris.php';
        });
    </script>
</body>
</html>