<?php
// Çıktı tamponlamasını başlat
ob_start();

// Hata raporlama
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Session başlat
session_start();

// Veritabanı bağlantısı
require_once '../config/db.php';

// Yönetici girişi kontrolü
if(!isset($_SESSION['admin_id'])) {
    header("Location: giris.php");
    exit();
}

// Kullanıcı rolünü veritabanından kontrol et
$admin_check = $conn->prepare("SELECT role FROM users WHERE id = ? AND role = 'admin'");
$admin_check->execute([$_SESSION['admin_id']]);
if(!$admin_check->fetch()) {
    header("Location: giris.php");
    exit();
}

// Kullanıcı ekleme işlemi
if(isset($_POST['add_user'])) {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = $_POST['password'];
    $role = $_POST['role'];
    $status = $_POST['status'];
    $balance = floatval($_POST['balance']);

    $errors = [];

    // Validasyonlar
    if(empty($username)) {
        $errors[] = "Kullanıcı adı gereklidir.";
    } elseif(strlen($username) < 3) {
        $errors[] = "Kullanıcı adı en az 3 karakter olmalıdır.";
    }

    if(empty($email)) {
        $errors[] = "E-posta adresi gereklidir.";
    } elseif(!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Geçerli bir e-posta adresi giriniz.";
    }

    if(empty($password)) {
        $errors[] = "Şifre gereklidir.";
    } elseif(strlen($password) < 6) {
        $errors[] = "Şifre en az 6 karakter olmalıdır.";
    }

    // Kullanıcı adı ve e-posta kontrolü
    $check = $conn->prepare("SELECT COUNT(*) FROM users WHERE username = ? OR email = ?");
    $check->execute([$username, $email]);
    if($check->fetchColumn() > 0) {
        $errors[] = "Bu kullanıcı adı veya e-posta adresi zaten kullanılıyor.";
    }

    if(empty($errors)) {
        try {
            $stmt = $conn->prepare("
                INSERT INTO users (username, email, password, role, status, balance, created_at, updated_at)
                VALUES (?, ?, ?, ?, ?, ?, NOW(), NOW())
            ");
            
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt->execute([$username, $email, $hashed_password, $role, $status, $balance]);
            
            header("Location: users.php?success=added");
            exit();
        } catch(PDOException $e) {
            $errors[] = "Kullanıcı eklenirken bir hata oluştu: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Yeni Kullanıcı Ekle - NextGen SMM Panel</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.2.1/flowbite.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <style>
        .neo-gradient {
            background: linear-gradient(120deg, #2E3192, #1BFFFF);
        }
        .text-gradient {
            background: linear-gradient(to right, #1BFFFF, #2E3192);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
    </style>
</head>
<body class="bg-[#0A0A1B]">

<!-- Sidebar -->
<aside id="logo-sidebar" class="fixed top-0 left-0 z-40 w-64 h-screen transition-transform -translate-x-full sm:translate-x-0" aria-label="Sidebar">
   <div class="h-full px-3 py-4 overflow-y-auto bg-[#12122C]">
      <a href="index.php" class="flex items-center ps-2.5 mb-5">
         <span class="self-center text-xl font-semibold whitespace-nowrap text-white">NextGen <span class="text-gradient">SMM Panel</span></span>
      </a>
      <ul class="space-y-2 font-medium">
         <li>
            <a href="index.php" class="flex items-center p-2 text-white rounded-lg hover:bg-gray-700 group">
               <i class="fas fa-home w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Dashboard</span>
            </a>
         </li>
         <li>
            <a href="users.php" class="flex items-center p-2 text-white rounded-lg hover:bg-gray-700 group">
               <i class="fas fa-users w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Kullanıcılar</span>
            </a>
         </li>
         <li>
            <a href="services.php" class="flex items-center p-2 text-white rounded-lg hover:bg-gray-700 group">
               <i class="fas fa-list w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Servisler</span>
            </a>
         </li>
         <li>
            <a href="orders.php" class="flex items-center p-2 text-white rounded-lg hover:bg-gray-700 group">
               <i class="fas fa-shopping-cart w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Siparişler</span>
            </a>
         </li>
         <li>
            <a href="tickets.php" class="flex items-center p-2 text-white rounded-lg hover:bg-gray-700 group">
               <i class="fas fa-ticket-alt w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Destek Talepleri</span>
            </a>
         </li>
         <li>
            <a href="bank.php" class="flex items-center p-2 text-white rounded-lg bg-gray-700 group">
               <i class="fas fa-credit-card w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Bakiye İşlemleri</span>
            </a>
         </li>
         <li>
            <a href="settings.php" class="flex items-center p-2 text-white rounded-lg hover:bg-gray-700 group">
               <i class="fas fa-cog w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Ayarlar</span>
            </a>
         </li>
         <li>
            <a href="logout.php" class="flex items-center p-2 text-white rounded-lg hover:bg-gray-700 group">
               <i class="fas fa-sign-out-alt w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Çıkış Yap</span>
            </a>
         </li>
      </ul>
   </div>
</aside>

<!-- Ana İçerik -->
<div class="p-4 sm:ml-64">
    <div class="p-4 mt-14">
        <!-- Başlık -->
        <div class="flex justify-between items-center mb-6">
            <h2 class="text-2xl font-bold text-white">Yeni Kullanıcı Ekle</h2>
            <a href="users.php" class="px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700">
                <i class="fas fa-arrow-left mr-2"></i>Geri Dön
            </a>
        </div>

        <?php if(!empty($errors)): ?>
        <div class="p-4 mb-6 text-sm text-red-800 rounded-lg bg-red-50" role="alert">
            <ul class="list-disc list-inside">
                <?php foreach($errors as $error): ?>
                    <li><?= htmlspecialchars($error) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
        <?php endif; ?>

        <!-- Kullanıcı Ekleme Formu -->
        <div class="bg-[#12122C] rounded-lg shadow p-6">
            <form method="POST" class="space-y-6">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label class="block mb-2 text-sm font-medium text-white">Kullanıcı Adı</label>
                        <input type="text" name="username" value="<?= isset($_POST['username']) ? htmlspecialchars($_POST['username']) : '' ?>" 
                               class="bg-gray-700 border border-gray-600 text-white text-sm rounded-lg block w-full p-2.5" 
                               placeholder="Kullanıcı adı">
                    </div>
                    
                    <div>
                        <label class="block mb-2 text-sm font-medium text-white">E-posta</label>
                        <input type="email" name="email" value="<?= isset($_POST['email']) ? htmlspecialchars($_POST['email']) : '' ?>"
                               class="bg-gray-700 border border-gray-600 text-white text-sm rounded-lg block w-full p-2.5" 
                               placeholder="ornek@email.com">
                    </div>

                    <div>
                        <label class="block mb-2 text-sm font-medium text-white">Şifre</label>
                        <input type="password" name="password" 
                               class="bg-gray-700 border border-gray-600 text-white text-sm rounded-lg block w-full p-2.5" 
                               placeholder="••••••••">
                    </div>

                    <div>
                        <label class="block mb-2 text-sm font-medium text-white">Bakiye</label>
                        <input type="number" step="0.01" name="balance" value="<?= isset($_POST['balance']) ? htmlspecialchars($_POST['balance']) : '0.00' ?>"
                               class="bg-gray-700 border border-gray-600 text-white text-sm rounded-lg block w-full p-2.5" 
                               placeholder="0.00">
                    </div>

                    <div>
                        <label class="block mb-2 text-sm font-medium text-white">Rol</label>
                        <select name="role" class="bg-gray-700 border border-gray-600 text-white text-sm rounded-lg block w-full p-2.5">
                            <option value="user" <?= (isset($_POST['role']) && $_POST['role'] == 'user') ? 'selected' : '' ?>>User</option>
                            <option value="reseller" <?= (isset($_POST['role']) && $_POST['role'] == 'reseller') ? 'selected' : '' ?>>Reseller</option>
                        </select>
                    </div>

                    <div>
                        <label class="block mb-2 text-sm font-medium text-white">Durum</label>
                        <select name="status" class="bg-gray-700 border border-gray-600 text-white text-sm rounded-lg block w-full p-2.5">
                            <option value="active" <?= (isset($_POST['status']) && $_POST['status'] == 'active') ? 'selected' : '' ?>>Active</option>
                            <option value="suspended" <?= (isset($_POST['status']) && $_POST['status'] == 'suspended') ? 'selected' : '' ?>>Suspended</option>
                            <option value="banned" <?= (isset($_POST['status']) && $_POST['status'] == 'banned') ? 'selected' : '' ?>>Banned</option>
                        </select>
                    </div>
                </div>

                <button type="submit" name="add_user" class="w-full text-white bg-blue-600 hover:bg-blue-700 font-medium rounded-lg text-sm px-5 py-2.5 text-center">
                    Kullanıcı Ekle
                </button>
            </form>
        </div>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.2.1/flowbite.min.js"></script>
</body>
</html>
<?php
// Çıktı tamponlamasını sonlandır
ob_end_flush();
?>