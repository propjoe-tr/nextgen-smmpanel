<?php
// Önce session'ı başlat
session_start();

// Hata raporlamasını ayarla
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Yönetici girişi kontrolü
if(!isset($_SESSION['admin_id'])) {
    header("Location: giris.php");
    exit();
}

// Veritabanı bağlantısını yap
require_once '../config/db.php';

// Kullanıcının admin olup olmadığını kontrol et
$stmt = $conn->prepare("SELECT role FROM users WHERE id = ?");
$stmt->execute([$_SESSION['admin_id']]);
$user = $stmt->fetch();

if(!$user || $user['role'] !== 'admin') {
    header("Location: giris.php");
    exit();
}

// Bakiye talebini işle
if(isset($_POST['action']) && isset($_POST['transaction_id'])) {
    $transaction_id = intval($_POST['transaction_id']);
    $action = $_POST['action'];
    $admin_note = $_POST['admin_note'] ?? '';

    if($action === 'approve' || $action === 'reject') {
        try {
            $conn->beginTransaction();

            // İşlemi getir
            $stmt = $conn->prepare("SELECT t.*, u.balance as current_balance FROM transactions t 
                                  JOIN users u ON t.user_id = u.id 
                                  WHERE t.id = ? AND t.type = 'deposit' AND t.status = 'pending'");
            $stmt->execute([$transaction_id]);
            $transaction = $stmt->fetch();

            if($transaction) {
                if($action === 'approve') {
                    // Kullanıcı bakiyesini güncelle
                    $new_balance = $transaction['current_balance'] + $transaction['amount'];
                    $stmt = $conn->prepare("UPDATE users SET balance = ? WHERE id = ?");
                    $stmt->execute([$new_balance, $transaction['user_id']]);

                    // İşlem durumunu güncelle
                    $stmt = $conn->prepare("UPDATE transactions SET status = 'completed', admin_note = ?, balance_after = ? WHERE id = ?");
                    $stmt->execute([$admin_note, $new_balance, $transaction_id]);
                } else {
                    // İşlemi reddet
                    $stmt = $conn->prepare("UPDATE transactions SET status = 'cancelled', admin_note = ? WHERE id = ?");
                    $stmt->execute([$admin_note, $transaction_id]);
                }

                $conn->commit();
                header("Location: bank.php?success=1");
                exit();
            }
        } catch(Exception $e) {
            $conn->rollBack();
            $error = "İşlem sırasında bir hata oluştu: " . $e->getMessage();
        }
    }
}

// Bakiye taleplerini getir
$transactions = $conn->query("
    SELECT t.*, u.username, u.email 
    FROM transactions t 
    JOIN users u ON t.user_id = u.id 
    WHERE t.type = 'deposit'
    ORDER BY t.created_at DESC
")->fetchAll();
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bakiye Talepleri - NextGen SMM Panel</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.2.1/flowbite.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <style>
        .neo-gradient {
            background: linear-gradient(120deg, #2E3192, #1BFFFF);
        }
        .text-gradient {
            background: linear-gradient(to right, #1BFFFF, #2E3192);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
    </style>
</head>
<body class="bg-[#0A0A1B]">

<button data-drawer-target="logo-sidebar" data-drawer-toggle="logo-sidebar" aria-controls="logo-sidebar" type="button" class="inline-flex items-center p-2 mt-2 ms-3 text-sm text-gray-500 rounded-lg sm:hidden hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200">
   <span class="sr-only">Open sidebar</span>
   <svg class="w-6 h-6" aria-hidden="true" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
      <path clip-rule="evenodd" fill-rule="evenodd" d="M2 4.75A.75.75 0 012.75 4h14.5a.75.75 0 010 1.5H2.75A.75.75 0 012 4.75zm0 10.5a.75.75 0 01.75-.75h7.5a.75.75 0 010 1.5h-7.5a.75.75 0 01-.75-.75zM2 10a.75.75 0 01.75-.75h14.5a.75.75 0 010 1.5H2.75A.75.75 0 012 10z"></path>
   </svg>
</button>

<aside id="logo-sidebar" class="fixed top-0 left-0 z-40 w-64 h-screen transition-transform -translate-x-full sm:translate-x-0" aria-label="Sidebar">
   <div class="h-full px-3 py-4 overflow-y-auto bg-[#12122C]">
      <a href="index.php" class="flex items-center ps-2.5 mb-5">
         <span class="self-center text-xl font-semibold whitespace-nowrap text-white">NextGen <span class="text-gradient">SMM Panel</span></span>
      </a>
      <ul class="space-y-2 font-medium">
         <li>
            <a href="index.php" class="flex items-center p-2 text-white rounded-lg hover:bg-gray-700 group">
               <i class="fas fa-home w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Dashboard</span>
            </a>
         </li>
         <li>
            <a href="users.php" class="flex items-center p-2 text-white rounded-lg hover:bg-gray-700 group">
               <i class="fas fa-users w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Kullanıcılar</span>
            </a>
         </li>
         <li>
            <a href="services.php" class="flex items-center p-2 text-white rounded-lg hover:bg-gray-700 group">
               <i class="fas fa-list w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Servisler</span>
            </a>
         </li>
         <li>
            <a href="orders.php" class="flex items-center p-2 text-white rounded-lg hover:bg-gray-700 group">
               <i class="fas fa-shopping-cart w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Siparişler</span>
            </a>
         </li>
         <li>
            <a href="tickets.php" class="flex items-center p-2 text-white rounded-lg hover:bg-gray-700 group">
               <i class="fas fa-ticket-alt w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Destek Talepleri</span>
            </a>
         </li>
         <li>
            <a href="bank.php" class="flex items-center p-2 text-white rounded-lg bg-gray-700 group">
               <i class="fas fa-credit-card w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Bakiye İşlemleri</span>
            </a>
         </li>
         <li>
            <a href="settings.php" class="flex items-center p-2 text-white rounded-lg hover:bg-gray-700 group">
               <i class="fas fa-cog w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Ayarlar</span>
            </a>
         </li>
         <li>
            <a href="logout.php" class="flex items-center p-2 text-white rounded-lg hover:bg-gray-700 group">
               <i class="fas fa-sign-out-alt w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Çıkış Yap</span>
            </a>
         </li>
      </ul>
   </div>
</aside>
<div class="p-4 sm:ml-64">
    <div class="p-4 mt-14">
        <div class="grid gap-4 mb-4">
            <div class="block p-6 bg-[#12122C] border border-gray-200 rounded-lg shadow">
                <div class="mb-4 text-white text-2xl font-bold flex items-center">
                    <i class="fas fa-credit-card mr-2"></i>
                    Bakiye İşlemleri
                </div>

                <?php if(isset($_GET['success'])): ?>
                <div class="p-4 mb-4 text-sm text-green-400 bg-green-900 rounded-lg">
                    İşlem başarıyla tamamlandı!
                </div>
                <?php endif; ?>

                <?php if(isset($error)): ?>
                <div class="p-4 mb-4 text-sm text-red-400 bg-red-900 rounded-lg">
                    <?= htmlspecialchars($error) ?>
                </div>
                <?php endif; ?>

                <div class="relative overflow-x-auto shadow-md sm:rounded-lg">
                    <table class="w-full text-sm text-left text-gray-400">
                        <thead class="text-xs uppercase bg-gray-700 text-gray-400">
                            <tr>
                                <th scope="col" class="px-6 py-3">ID</th>
                                <th scope="col" class="px-6 py-3">Kullanıcı</th>
                                <th scope="col" class="px-6 py-3">Miktar</th>
                                <th scope="col" class="px-6 py-3">Ödeme Yöntemi</th>
                                <th scope="col" class="px-6 py-3">Detaylar</th>
                                <th scope="col" class="px-6 py-3">Durum</th>
                                <th scope="col" class="px-6 py-3">Tarih</th>
                                <th scope="col" class="px-6 py-3">İşlemler</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach($transactions as $transaction): ?>
                            <tr class="border-b bg-[#12122C] border-gray-700">
                                <td class="px-6 py-4">#<?= $transaction['id'] ?></td>
                                <td class="px-6 py-4">
                                    <?= htmlspecialchars($transaction['username']) ?><br>
                                    <span class="text-xs text-gray-500"><?= htmlspecialchars($transaction['email']) ?></span>
                                </td>
                                <td class="px-6 py-4"><?= number_format($transaction['amount'], 2) ?> ₺</td>
                                <td class="px-6 py-4"><?= htmlspecialchars($transaction['payment_method']) ?></td>
                                <td class="px-6 py-4">
                                    <button data-modal-target="details-<?= $transaction['id'] ?>" data-modal-toggle="details-<?= $transaction['id'] ?>" class="text-blue-500 hover:underline">
                                        Detayları Gör
                                    </button>
                                </td>
                                <td class="px-6 py-4">
                                    <span class="px-2 py-1 rounded text-xs 
                                        <?php
                                        switch($transaction['status']) {
                                            case 'completed':
                                                echo 'bg-green-900 text-green-300';
                                                break;
                                            case 'pending':
                                                echo 'bg-yellow-900 text-yellow-300';
                                                break;
                                            case 'cancelled':
                                                echo 'bg-red-900 text-red-300';
                                                break;
                                        }
                                        ?>">
                                        <?php
                                        switch($transaction['status']) {
                                            case 'completed':
                                                echo 'Tamamlandı';
                                                break;
                                            case 'pending':
                                                echo 'Beklemede';
                                                break;
                                            case 'cancelled':
                                                echo 'İptal Edildi';
                                                break;
                                            default:
                                                echo ucfirst($transaction['status']);
                                        }
                                        ?>
                                    </span>
                                </td>
                                <td class="px-6 py-4"><?= date('d.m.Y H:i', strtotime($transaction['created_at'])) ?></td>
                                <td class="px-6 py-4">
                                    <?php if($transaction['status'] === 'pending'): ?>
                                    <button data-modal-target="action-<?= $transaction['id'] ?>" data-modal-toggle="action-<?= $transaction['id'] ?>" class="text-white bg-blue-600 hover:bg-blue-700 px-3 py-1 rounded">
                                        İşlem Yap
                                    </button>
                                    <?php endif; ?>
                                </td>
                            </tr>

                            <!-- Detay Modal -->
                            <div id="details-<?= $transaction['id'] ?>" tabindex="-1" class="fixed top-0 left-0 right-0 z-50 hidden w-full p-4 overflow-x-hidden overflow-y-auto md:inset-0 h-[calc(100%-1rem)] max-h-full">
                                <div class="relative w-full max-w-md max-h-full">
                                    <div class="relative bg-[#12122C] rounded-lg shadow">
                                        <div class="flex items-center justify-between p-4 border-b border-gray-700">
                                            <h3 class="text-xl font-semibold text-white">
                                                Ödeme Detayları
                                            </h3>
                                            <button type="button" class="text-gray-400 bg-transparent hover:bg-gray-700 rounded-lg text-sm w-8 h-8 ml-auto inline-flex justify-center items-center" data-modal-hide="details-<?= $transaction['id'] ?>">
                                                <i class="fas fa-times"></i>
                                            </button>
                                        </div>
                                        <div class="p-6 space-y-6">
                                            <p class="text-gray-400 whitespace-pre-wrap"><?= nl2br(htmlspecialchars($transaction['payment_details'])) ?></p>
                                            <?php if($transaction['admin_note']): ?>
                                                <div class="mt-4">
                                                    <h4 class="text-white font-semibold mb-2">Yönetici Notu:</h4>
                                                    <p class="text-gray-400"><?= nl2br(htmlspecialchars($transaction['admin_note'])) ?></p>
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- İşlem Modal -->
                            <?php if($transaction['status'] === 'pending'): ?>
                            <div id="action-<?= $transaction['id'] ?>" tabindex="-1" class="fixed top-0 left-0 right-0 z-50 hidden w-full p-4 overflow-x-hidden overflow-y-auto md:inset-0 h-[calc(100%-1rem)] max-h-full">
                                <div class="relative w-full max-w-md max-h-full">
                                    <div class="relative bg-[#12122C] rounded-lg shadow">
                                        <div class="flex items-center justify-between p-4 border-b border-gray-700">
                                            <h3 class="text-xl font-semibold text-white">
                                                Bakiye Talebi İşlemi
                                            </h3>
                                            <button type="button" class="text-gray-400 bg-transparent hover:bg-gray-700 rounded-lg text-sm w-8 h-8 ml-auto inline-flex justify-center items-center" data-modal-hide="action-<?= $transaction['id'] ?>">
                                                <i class="fas fa-times"></i>
                                            </button>
                                        </div>
                                        <form method="POST">
                                            <input type="hidden" name="transaction_id" value="<?= $transaction['id'] ?>">
                                            <div class="p-6 space-y-6">
                                                <div class="mb-4">
                                                    <label class="block text-white text-sm font-bold mb-2" for="admin_note">
                                                        Yönetici Notu
                                                    </label>
                                                    <textarea name="admin_note" id="admin_note" rows="3" class="bg-gray-700 text-white rounded w-full p-2"></textarea>
                                                </div>
                                                <div class="flex justify-end space-x-3">
                                                    <button type="submit" name="action" value="reject" class="text-white bg-red-600 hover:bg-red-700 px-4 py-2 rounded">
                                                        Reddet
                                                    </button>
                                                    <button type="submit" name="action" value="approve" class="text-white bg-green-600 hover:bg-green-700 px-4 py-2 rounded">
                                                        Onayla
                                                    </button>
                                                </div>
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <?php endif; ?>

                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.2.1/flowbite.min.js"></script>
</body>
</html>