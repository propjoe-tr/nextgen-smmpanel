<?php
error_reporting(0);
session_start();

// Yönetici girişi kontrolü
if (!isset($_SESSION['admin_id'])) {
    header("Location: giris.php");
    exit();
}

require_once '../config/db.php';

// Kullanıcının rolünü veritabanından kontrol edelim
$stmt = $conn->prepare("SELECT role FROM users WHERE id = ?");
$stmt->execute([$_SESSION['admin_id']]);
$user = $stmt->fetch();

if (!$user || $user['role'] !== 'admin') {
    header("Location: giris.php");
    exit();
}

// Sipariş durumu güncelleme işlemi
if(isset($_POST['update_status'])) {
    $order_id = $_POST['order_id'];
    $new_status = $_POST['status'];
    
    $stmt = $conn->prepare("UPDATE orders SET status = ? WHERE id = ?");
    $stmt->execute([$new_status, $order_id]);
    
    header("Location: orders.php?success=1");
    exit();
}

// Siparişleri çek
$orders = $conn->query("
    SELECT o.*, u.username, s.name as service_name 
    FROM orders o 
    JOIN users u ON o.user_id = u.id 
    JOIN services s ON o.service_id = s.id 
    ORDER BY o.created_at DESC
")->fetchAll();
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Siparişler - NextGen SMM Panel</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.2.1/flowbite.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <style>
        .neo-gradient {
            background: linear-gradient(120deg, #2E3192, #1BFFFF);
        }
        .text-gradient {
            background: linear-gradient(to right, #1BFFFF, #2E3192);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
    </style>
</head>
<body class="bg-[#0A0A1B]">

<!-- Sidebar -->
<button data-drawer-target="logo-sidebar" data-drawer-toggle="logo-sidebar" aria-controls="logo-sidebar" type="button" class="inline-flex items-center p-2 mt-2 ms-3 text-sm text-gray-500 rounded-lg sm:hidden hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200">
   <span class="sr-only">Open sidebar</span>
   <svg class="w-6 h-6" aria-hidden="true" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
      <path clip-rule="evenodd" fill-rule="evenodd" d="M2 4.75A.75.75 0 012.75 4h14.5a.75.75 0 010 1.5H2.75A.75.75 0 012 4.75zm0 10.5a.75.75 0 01.75-.75h7.5a.75.75 0 010 1.5h-7.5a.75.75 0 01-.75-.75zM2 10a.75.75 0 01.75-.75h14.5a.75.75 0 010 1.5H2.75A.75.75 0 012 10z"></path>
   </svg>
</button>

<aside id="logo-sidebar" class="fixed top-0 left-0 z-40 w-64 h-screen transition-transform -translate-x-full sm:translate-x-0" aria-label="Sidebar">
   <div class="h-full px-3 py-4 overflow-y-auto bg-[#12122C]">
      <a href="index.php" class="flex items-center ps-2.5 mb-5">
         <span class="self-center text-xl font-semibold whitespace-nowrap text-white">NextGen <span class="text-gradient">SMM Panel</span></span>
      </a>
      <ul class="space-y-2 font-medium">
         <li>
            <a href="index.php" class="flex items-center p-2 text-white rounded-lg hover:bg-gray-700 group">
               <i class="fas fa-home w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Dashboard</span>
            </a>
         </li>
         <li>
            <a href="users.php" class="flex items-center p-2 text-white rounded-lg hover:bg-gray-700 group">
               <i class="fas fa-users w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Kullanıcılar</span>
            </a>
         </li>
         <li>
            <a href="services.php" class="flex items-center p-2 text-white rounded-lg hover:bg-gray-700 group">
               <i class="fas fa-list w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Servisler</span>
            </a>
         </li>
         <li>
            <a href="orders.php" class="flex items-center p-2 text-white rounded-lg hover:bg-gray-700 group">
               <i class="fas fa-shopping-cart w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Siparişler</span>
            </a>
         </li>
         <li>
            <a href="tickets.php" class="flex items-center p-2 text-white rounded-lg hover:bg-gray-700 group">
               <i class="fas fa-ticket-alt w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Destek Talepleri</span>
            </a>
         </li>
         <li>
            <a href="bank.php" class="flex items-center p-2 text-white rounded-lg bg-gray-700 group">
               <i class="fas fa-credit-card w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Bakiye İşlemleri</span>
            </a>
         </li>
         <li>
            <a href="settings.php" class="flex items-center p-2 text-white rounded-lg hover:bg-gray-700 group">
               <i class="fas fa-cog w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Ayarlar</span>
            </a>
         </li>
         <li>
            <a href="logout.php" class="flex items-center p-2 text-white rounded-lg hover:bg-gray-700 group">
               <i class="fas fa-sign-out-alt w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Çıkış Yap</span>
            </a>
         </li>
      </ul>
   </div>
</aside>

<!-- Ana İçerik -->
<div class="p-4 sm:ml-64">
    <div class="p-4 mt-14">
        <div class="bg-[#12122C] rounded-lg p-4">
            <div class="flex justify-between items-center mb-4">
                <h2 class="text-xl font-bold text-white">Tüm Siparişler</h2>
                <?php if(isset($_GET['success'])): ?>
                    <div class="text-green-500">Sipariş durumu başarıyla güncellendi!</div>
                <?php endif; ?>
            </div>
            
            <div class="overflow-x-auto">
                <table class="w-full text-sm text-left text-gray-400">
                    <thead class="text-xs uppercase bg-gray-700 text-gray-400">
                        <tr>
                            <th scope="col" class="px-6 py-3">ID</th>
                            <th scope="col" class="px-6 py-3">Kullanıcı</th>
                            <th scope="col" class="px-6 py-3">Servis</th>
                            <th scope="col" class="px-6 py-3">Link</th>
                            <th scope="col" class="px-6 py-3">Miktar</th>
                            <th scope="col" class="px-6 py-3">Tutar</th>
                            <th scope="col" class="px-6 py-3">Durum</th>
                            <th scope="col" class="px-6 py-3">Tarih</th>
                            <th scope="col" class="px-6 py-3">İşlemler</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($orders as $order): ?>
                        <tr class="border-b bg-[#12122C] border-gray-700">
                            <td class="px-6 py-4">#<?= $order['id'] ?></td>
                            <td class="px-6 py-4"><?= htmlspecialchars($order['username']) ?></td>
                            <td class="px-6 py-4"><?= htmlspecialchars($order['service_name']) ?></td>
                            <td class="px-6 py-4">
                                <a href="<?= htmlspecialchars($order['link']) ?>" target="_blank" class="text-blue-500 hover:text-blue-400">
                                    <?= substr(htmlspecialchars($order['link']), 0, 30) ?>...
                                </a>
                            </td>
                            <td class="px-6 py-4"><?= number_format($order['quantity']) ?></td>
                            <td class="px-6 py-4"><?= number_format($order['amount'], 2) ?> ₺</td>
                            <td class="px-6 py-4">
                                <span class="px-2 py-1 rounded text-xs 
                                    <?php
                                    switch($order['status']) {
                                        case 'completed':
                                            echo 'bg-green-900 text-green-300';
                                            break;
                                        case 'pending':
                                            echo 'bg-yellow-900 text-yellow-300';
                                            break;
                                        case 'processing':
                                            echo 'bg-blue-900 text-blue-300';
                                            break;
                                        case 'cancelled':
                                            echo 'bg-red-900 text-red-300';
                                            break;
                                        case 'error':
                                            echo 'bg-red-900 text-red-300';
                                            break;
                                        case 'partial':
                                            echo 'bg-orange-900 text-orange-300';
                                            break;
                                    }
                                    ?>">
                                    <?= ucfirst($order['status']) ?>
                                </span>
                            </td>
                            <td class="px-6 py-4"><?= date('d.m.Y H:i', strtotime($order['created_at'])) ?></td>
                            <td class="px-6 py-4">
                                <button onclick="openEditModal(<?= $order['id'] ?>, '<?= $order['status'] ?>')" 
                                        class="text-blue-500 hover:text-blue-400">
                                    <i class="fas fa-edit"></i>
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Düzenleme Modal -->
<div id="editModal" tabindex="-1" aria-hidden="true" class="fixed top-0 left-0 right-0 z-50 hidden w-full p-4 overflow-x-hidden overflow-y-auto md:inset-0 h-[calc(100%-1rem)] max-h-full">
    <div class="relative w-full max-w-md max-h-full">
        <div class="relative bg-[#12122C] rounded-lg shadow">
            <div class="flex items-start justify-between p-4 border-b rounded-t border-gray-600">
                <h3 class="text-xl font-semibold text-white">
                    Sipariş Durumunu Güncelle
                </h3>
                <button type="button" class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ml-auto inline-flex justify-center items-center" data-modal-hide="editModal">
                    <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 14 14">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6"/>
                    </svg>
                </button>
            </div>
            <form method="POST">
                <div class="p-6 space-y-6">
                    <input type="hidden" name="order_id" id="modal_order_id">
                    <div>
                        <label for="status" class="block mb-2 text-sm font-medium text-white">Durum</label>
                        <select name="status" id="modal_status" class="bg-gray-700 border border-gray-600 text-white text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5">
                            <option value="pending">Beklemede</option>
                            <option value="processing">İşleniyor</option>
                            <option value="completed">Tamamlandı</option>
                            <option value="cancelled">İptal Edildi</option>
                            <option value="error">Hata</option>
                            <option value="partial">Kısmi Tamamlandı</option>
                        </select>
                    </div>
                </div>
                <div class="flex items-center p-6 space-x-2 border-t rounded-b border-gray-600">
                    <button type="submit" name="update_status" class="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center">Güncelle</button>
                    <button data-modal-hide="editModal" type="button" class="text-gray-300 bg-gray-700 hover:bg-gray-600 focus:ring-4 focus:outline-none focus:ring-gray-200 rounded-lg border border-gray-500 text-sm font-medium px-5 py-2.5 hover:text-white focus:z-10">İptal</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.2.1/flowbite.min.js"></script>
<script>
function openEditModal(orderId, currentStatus) {
    document.getElementById('modal_order_id').value = orderId;
    document.getElementById('modal_status').value = currentStatus;
    
    const modal = new Modal(document.getElementById('editModal'));
    modal.show();
}
</script>
</body>
</html>