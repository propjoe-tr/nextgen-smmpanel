<?php
ob_start();
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Yönetici girişi kontrolü
if(!isset($_SESSION['admin_id'])) {
    header("Location: giris.php");
    exit();
}

require_once '../config/db.php';

// Servis işlemleri
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add':
                $stmt = $conn->prepare("INSERT INTO services (category_id, name, description, price, min_amount, max_amount, type, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
                $stmt->execute([
                    $_POST['category_id'],
                    $_POST['name'],
                    $_POST['description'],
                    $_POST['price'],
                    $_POST['min_amount'],
                    $_POST['max_amount'],
                    $_POST['type'] ?? 'default',
                    $_POST['status']
                ]);
                header("Location: services.php");
                exit();
                break;

            case 'edit':
                $stmt = $conn->prepare("UPDATE services SET category_id = ?, name = ?, description = ?, price = ?, min_amount = ?, max_amount = ?, type = ?, status = ? WHERE id = ?");
                $stmt->execute([
                    $_POST['category_id'],
                    $_POST['name'],
                    $_POST['description'],
                    $_POST['price'],
                    $_POST['min_amount'],
                    $_POST['max_amount'],
                    $_POST['type'] ?? 'default',
                    $_POST['status'],
                    $_POST['service_id']
                ]);
                header("Location: services.php");
                exit();
                break;

            case 'delete':
                $stmt = $conn->prepare("DELETE FROM services WHERE id = ?");
                $stmt->execute([$_POST['service_id']]);
                header("Location: services.php");
                exit();
                break;
        }
    }
}

// Kategorileri çek
$categories = $conn->query("SELECT * FROM categories ORDER BY sort_order")->fetchAll();

// Servisleri çek
$services = $conn->query("
    SELECT s.*, c.name as category_name 
    FROM services s 
    LEFT JOIN categories c ON s.category_id = c.id 
    ORDER BY s.id DESC
")->fetchAll();
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Servis Yönetimi - NextGen SMM Panel</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.2.1/flowbite.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <style>
        .neo-gradient {
            background: linear-gradient(120deg, #2E3192, #1BFFFF);
        }
        .text-gradient {
            background: linear-gradient(to right, #1BFFFF, #2E3192);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
    </style>
</head>
<body class="bg-[#0A0A1B]">

<button data-drawer-target="logo-sidebar" data-drawer-toggle="logo-sidebar" aria-controls="logo-sidebar" type="button" class="inline-flex items-center p-2 mt-2 ms-3 text-sm text-gray-500 rounded-lg sm:hidden hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200">
   <span class="sr-only">Open sidebar</span>
   <svg class="w-6 h-6" aria-hidden="true" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
      <path clip-rule="evenodd" fill-rule="evenodd" d="M2 4.75A.75.75 0 012.75 4h14.5a.75.75 0 010 1.5H2.75A.75.75 0 012 4.75zm0 10.5a.75.75 0 01.75-.75h7.5a.75.75 0 010 1.5h-7.5a.75.75 0 01-.75-.75zM2 10a.75.75 0 01.75-.75h14.5a.75.75 0 010 1.5H2.75A.75.75 0 012 10z"></path>
   </svg>
</button>

<!-- Sidebar -->
<aside id="logo-sidebar" class="fixed top-0 left-0 z-40 w-64 h-screen transition-transform -translate-x-full sm:translate-x-0" aria-label="Sidebar">
   <div class="h-full px-3 py-4 overflow-y-auto bg-[#12122C]">
      <a href="index.php" class="flex items-center ps-2.5 mb-5">
         <span class="self-center text-xl font-semibold whitespace-nowrap text-white">NextGen <span class="text-gradient">SMM Panel</span></span>
      </a>
      <ul class="space-y-2 font-medium">
         <li>
            <a href="index.php" class="flex items-center p-2 text-white rounded-lg hover:bg-gray-700 group">
               <i class="fas fa-home w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Dashboard</span>
            </a>
         </li>
         <li>
            <a href="users.php" class="flex items-center p-2 text-white rounded-lg hover:bg-gray-700 group">
               <i class="fas fa-users w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Kullanıcılar</span>
            </a>
         </li>
         <li>
            <a href="services.php" class="flex items-center p-2 text-white rounded-lg hover:bg-gray-700 group">
               <i class="fas fa-list w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Servisler</span>
            </a>
         </li>
         <li>
            <a href="orders.php" class="flex items-center p-2 text-white rounded-lg hover:bg-gray-700 group">
               <i class="fas fa-shopping-cart w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Siparişler</span>
            </a>
         </li>
         <li>
            <a href="tickets.php" class="flex items-center p-2 text-white rounded-lg hover:bg-gray-700 group">
               <i class="fas fa-ticket-alt w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Destek Talepleri</span>
            </a>
         </li>
         <li>
            <a href="bank.php" class="flex items-center p-2 text-white rounded-lg bg-gray-700 group">
               <i class="fas fa-credit-card w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Bakiye İşlemleri</span>
            </a>
         </li>
         <li>
            <a href="settings.php" class="flex items-center p-2 text-white rounded-lg hover:bg-gray-700 group">
               <i class="fas fa-cog w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Ayarlar</span>
            </a>
         </li>
         <li>
            <a href="logout.php" class="flex items-center p-2 text-white rounded-lg hover:bg-gray-700 group">
               <i class="fas fa-sign-out-alt w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Çıkış Yap</span>
            </a>
         </li>
      </ul>
   </div>
</aside>

<!-- Ana İçerik -->
<div class="p-4 sm:ml-64">
    <div class="p-4 mt-14">
        <div class="flex justify-between items-center mb-4">
            <h2 class="text-2xl font-bold text-white">Servisler</h2>
            <button data-modal-target="addServiceModal" data-modal-toggle="addServiceModal" class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700">
                <i class="fas fa-plus mr-2"></i>Yeni Servis Ekle
            </button>
        </div>

        <!-- Servis Tablosu -->
        <div class="bg-[#12122C] rounded-lg p-4">
            <div class="overflow-x-auto">
                <table class="w-full text-sm text-left text-gray-400">
                    <thead class="text-xs uppercase bg-gray-700 text-gray-400">
                        <tr>
                            <th class="px-6 py-3">ID</th>
                            <th class="px-6 py-3">Kategori</th>
                            <th class="px-6 py-3">Servis Adı</th>
                            <th class="px-6 py-3">Fiyat</th>
                            <th class="px-6 py-3">Min-Max</th>
                            <th class="px-6 py-3">Durum</th>
                            <th class="px-6 py-3">İşlemler</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($services as $service): ?>
                        <tr class="border-b bg-[#12122C] border-gray-700">
                            <td class="px-6 py-4">#<?= $service['id'] ?></td>
                            <td class="px-6 py-4"><?= htmlspecialchars($service['category_name']) ?></td>
                            <td class="px-6 py-4"><?= htmlspecialchars($service['name']) ?></td>
                            <td class="px-6 py-4"><?= number_format($service['price'], 2) ?> ₺</td>
                            <td class="px-6 py-4"><?= $service['min_amount'] ?>-<?= $service['max_amount'] ?></td>
                            <td class="px-6 py-4">
                                <span class="px-2 py-1 rounded text-xs <?= $service['status'] === 'active' ? 'bg-green-900 text-green-300' : 'bg-red-900 text-red-300' ?>">
                                    <?= ucfirst($service['status']) ?>
                                </span>
                            </td>
                            <td class="px-6 py-4">
                                <button onclick="editService(<?= htmlspecialchars(json_encode($service)) ?>)" class="text-blue-500 hover:text-blue-700 mr-2">
                                    <i class="fas fa-edit"></i>
                                </button>
                                <button onclick="deleteService(<?= $service['id'] ?>)" class="text-red-500 hover:text-red-700">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Servis Ekleme Modal -->
<div id="addServiceModal" tabindex="-1" aria-hidden="true" class="fixed top-0 left-0 right-0 z-50 hidden w-full p-4 overflow-x-hidden overflow-y-auto md:inset-0 h-[calc(100%-1rem)] max-h-full">
    <div class="relative w-full max-w-2xl max-h-full">
        <div class="relative bg-[#12122C] rounded-lg shadow">
            <div class="flex items-start justify-between p-4 border-b border-gray-600 rounded-t">
                <h3 class="text-xl font-semibold text-white">Yeni Servis Ekle</h3>
                <button type="button" class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ml-auto inline-flex justify-center items-center" data-modal-hide="addServiceModal">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <form action="services.php" method="POST">
                <input type="hidden" name="action" value="add">
                <div class="p-6 space-y-6">
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block mb-2 text-sm font-medium text-white">Kategori</label>
                            <select name="category_id" class="bg-gray-700 border border-gray-600 text-white text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5">
                                <?php foreach($categories as $category): ?>
                                    <option value="<?= $category['id'] ?>"><?= htmlspecialchars($category['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div>
                            <label class="block mb-2 text-sm font-medium text-white">Servis Adı</label>
                            <input type="text" name="name" class="bg-gray-700 border border-gray-600 text-white text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" required>
                        </div>
                        <div class="col-span-2">
                            <label class="block mb-2 text-sm font-medium text-white">Açıklama</label>
                            <textarea name="description" class="bg-gray-700 border border-gray-600 text-white text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" rows="3"></textarea>
                        </div>
                        <div>
                            <label class="block mb-2 text-sm font-medium text-white">Fiyat</label>
                            <input type="number" step="0.01" name="price" class="bg-gray-700 border border-gray-600 text-white text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" required>
                        </div>
                        <div>
                            <label class="block mb-2 text-sm font-medium text-white">Minimum Miktar</label>
                            <input type="number" name="min_amount" class="bg-gray-700 border border-gray-600 text-white text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" required>
                        </div>
                        <div>
                            <label class="block mb-2 text-sm font-medium text-white">Maksimum Miktar</label>
                            <input type="number" name="max_amount" class="bg-gray-700 border border-gray-600 text-white text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" required>
                        </div>
                        <div>
                            <label class="block mb-2 text-sm font-medium text-white">Durum</label>
                            <select name="status" class="bg-gray-700 border border-gray-600 text-white text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5">
                                <option value="active">Aktif</option>
                                <option value="inactive">Pasif</option>
                                <option value="hidden">Gizli</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="flex items-center p-6 space-x-2 border-t border-gray-600">
                    <button type="submit" class="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center">Kaydet</button>
                    <button type="button" class="text-gray-300 bg-gray-600 hover:bg-gray-700 focus:ring-4 focus:outline-none focus:ring-gray-200 rounded-lg border border-gray-200 text-sm font-medium px-5 py-2.5 hover:text-white focus:z-10" data-modal-hide="addServiceModal">İptal</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Servis Düzenleme Modal -->
<div id="editServiceModal" tabindex="-1" aria-hidden="true" class="fixed top-0 left-0 right-0 z-50 hidden w-full p-4 overflow-x-hidden overflow-y-auto md:inset-0 h-[calc(100%-1rem)] max-h-full">
    <div class="relative w-full max-w-2xl max-h-full">
        <div class="relative bg-[#12122C] rounded-lg shadow">
            <div class="flex items-start justify-between p-4 border-b border-gray-600 rounded-t">
                <h3 class="text-xl font-semibold text-white">Servis Düzenle</h3>
                <button type="button" class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ml-auto inline-flex justify-center items-center" data-modal-hide="editServiceModal">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <form action="services.php" method="POST">
                <input type="hidden" name="action" value="edit">
                <input type="hidden" name="service_id" id="edit_service_id">
                <div class="p-6 space-y-6">
                    <div class="grid grid-cols-2 gap-4">
                        <div>
                            <label class="block mb-2 text-sm font-medium text-white">Kategori</label>
                            <select name="category_id" id="edit_category_id" class="bg-gray-700 border border-gray-600 text-white text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5">
                                <?php foreach($categories as $category): ?>
                                    <option value="<?= $category['id'] ?>"><?= htmlspecialchars($category['name']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div>
                            <label class="block mb-2 text-sm font-medium text-white">Servis Adı</label>
                            <input type="text" name="name" id="edit_name" class="bg-gray-700 border border-gray-600 text-white text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" required>
                        </div>
                        <div class="col-span-2">
                            <label class="block mb-2 text-sm font-medium text-white">Açıklama</label>
                            <textarea name="description" id="edit_description" class="bg-gray-700 border border-gray-600 text-white text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" rows="3"></textarea>
                        </div>
                        <div>
                            <label class="block mb-2 text-sm font-medium text-white">Fiyat</label>
                            <input type="number" step="0.01" name="price" id="edit_price" class="bg-gray-700 border border-gray-600 text-white text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" required>
                        </div>
                        <div>
                            <label class="block mb-2 text-sm font-medium text-white">Minimum Miktar</label>
                            <input type="number" name="min_amount" id="edit_min_amount" class="bg-gray-700 border border-gray-600 text-white text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" required>
                        </div>
                        <div>
                            <label class="block mb-2 text-sm font-medium text-white">Maksimum Miktar</label>
                            <input type="number" name="max_amount" id="edit_max_amount" class="bg-gray-700 border border-gray-600 text-white text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5" required>
                        </div>
                        <div>
                            <label class="block mb-2 text-sm font-medium text-white">Durum</label>
                            <select name="status" id="edit_status" class="bg-gray-700 border border-gray-600 text-white text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5">
                                <option value="active">Aktif</option>
                                <option value="inactive">Pasif</option>
                                <option value="hidden">Gizli</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="flex items-center p-6 space-x-2 border-t border-gray-600">
                    <button type="submit" class="text-white bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-5 py-2.5 text-center">Güncelle</button>
                    <button type="button" class="text-gray-300 bg-gray-600 hover:bg-gray-700 focus:ring-4 focus:outline-none focus:ring-gray-200 rounded-lg border border-gray-200 text-sm font-medium px-5 py-2.5 hover:text-white focus:z-10" data-modal-hide="editServiceModal">İptal</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.2.1/flowbite.min.js"></script>
<script>
function editService(service) {
    // Form alanlarını doldur
    document.getElementById('edit_service_id').value = service.id;
    document.getElementById('edit_category_id').value = service.category_id;
    document.getElementById('edit_name').value = service.name;
    document.getElementById('edit_description').value = service.description;
    document.getElementById('edit_price').value = service.price;
    document.getElementById('edit_min_amount').value = service.min_amount;
    document.getElementById('edit_max_amount').value = service.max_amount;
    document.getElementById('edit_status').value = service.status;
    
    // Modalı aç
    const modal = document.getElementById('editServiceModal');
    const modalInstance = new Modal(modal);
    modalInstance.show();
}

function deleteService(serviceId) {
    if(confirm('Bu servisi silmek istediğinizden emin misiniz?')) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.action = 'services.php';
        
        const actionInput = document.createElement('input');
        actionInput.type = 'hidden';
        actionInput.name = 'action';
        actionInput.value = 'delete';
        
        const serviceInput = document.createElement('input');
        serviceInput.type = 'hidden';
        serviceInput.name = 'service_id';
        serviceInput.value = serviceId;
        
        form.appendChild(actionInput);
        form.appendChild(serviceInput);
        document.body.appendChild(form);
        form.submit();
    }
}
</script>
</body>
</html>
<?php ob_end_flush(); ?>