<?php
// Hata raporlama ve session başlatma
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();

// Yönetici girişi kontrolü - session kontrolü
if(!isset($_SESSION['admin_id'])) {
    header("Location: giris.php");
    exit();
}

require_once '../config/db.php';

// İstatistikleri çek
$stats = [];

try {
    // Toplam kullanıcı sayısı
    $userQuery = $conn->query("SELECT COUNT(*) FROM users WHERE role = 'user'");
    $stats['total_users'] = $userQuery->fetchColumn();

    // Toplam sipariş sayısı
    $orderQuery = $conn->query("SELECT COUNT(*) FROM orders");
    $stats['total_orders'] = $orderQuery->fetchColumn();

    // Toplam servis sayısı
    $serviceQuery = $conn->query("SELECT COUNT(*) FROM services");
    $stats['total_services'] = $serviceQuery->fetchColumn();

    // Toplam destek talebi
    $ticketQuery = $conn->query("SELECT COUNT(*) FROM tickets");
    $stats['total_tickets'] = $ticketQuery->fetchColumn();

    // Son siparişleri çek
    $recentOrders = $conn->query("
        SELECT o.*, u.username, s.name as service_name 
        FROM orders o 
        JOIN users u ON o.user_id = u.id 
        JOIN services s ON o.service_id = s.id 
        ORDER BY o.created_at DESC 
        LIMIT 5
    ")->fetchAll();

    // Son kullanıcıları çek
    $recentUsers = $conn->query("
        SELECT * FROM users 
        WHERE role = 'user' 
        ORDER BY created_at DESC 
        LIMIT 5
    ")->fetchAll();

} catch(PDOException $e) {
    // Hata durumunda varsayılan değerler
    $stats = [
        'total_users' => 0,
        'total_orders' => 0,
        'total_services' => 0,
        'total_tickets' => 0
    ];
    $recentOrders = [];
    $recentUsers = [];
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Yönetici Paneli - NextGen SMM Panel</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.2.1/flowbite.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <style>
        .neo-gradient {
            background: linear-gradient(120deg, #2E3192, #1BFFFF);
        }
        .text-gradient {
            background: linear-gradient(to right, #1BFFFF, #2E3192);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
    </style>
</head>
<body class="bg-[#0A0A1B]">

<button data-drawer-target="logo-sidebar" data-drawer-toggle="logo-sidebar" aria-controls="logo-sidebar" type="button" class="inline-flex items-center p-2 mt-2 ms-3 text-sm text-gray-500 rounded-lg sm:hidden hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200">
   <span class="sr-only">Open sidebar</span>
   <svg class="w-6 h-6" aria-hidden="true" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
      <path clip-rule="evenodd" fill-rule="evenodd" d="M2 4.75A.75.75 0 012.75 4h14.5a.75.75 0 010 1.5H2.75A.75.75 0 012 4.75zm0 10.5a.75.75 0 01.75-.75h7.5a.75.75 0 010 1.5h-7.5a.75.75 0 01-.75-.75zM2 10a.75.75 0 01.75-.75h14.5a.75.75 0 010 1.5H2.75A.75.75 0 012 10z"></path>
   </svg>
</button>

<!-- Sidebar -->
<aside id="logo-sidebar" class="fixed top-0 left-0 z-40 w-64 h-screen transition-transform -translate-x-full sm:translate-x-0" aria-label="Sidebar">
   <div class="h-full px-3 py-4 overflow-y-auto bg-[#12122C]">
      <a href="index.php" class="flex items-center ps-2.5 mb-5">
         <span class="self-center text-xl font-semibold whitespace-nowrap text-white">NextGen <span class="text-gradient">SMM Panel</span></span>
      </a>
      <ul class="space-y-2 font-medium">
         <li>
            <a href="index.php" class="flex items-center p-2 text-white rounded-lg hover:bg-gray-700 group">
               <i class="fas fa-home w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Dashboard</span>
            </a>
         </li>
         <li>
            <a href="users.php" class="flex items-center p-2 text-white rounded-lg hover:bg-gray-700 group">
               <i class="fas fa-users w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Kullanıcılar</span>
            </a>
         </li>
         <li>
            <a href="services.php" class="flex items-center p-2 text-white rounded-lg hover:bg-gray-700 group">
               <i class="fas fa-list w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Servisler</span>
            </a>
         </li>
         <li>
            <a href="orders.php" class="flex items-center p-2 text-white rounded-lg hover:bg-gray-700 group">
               <i class="fas fa-shopping-cart w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Siparişler</span>
            </a>
         </li>
         <li>
            <a href="tickets.php" class="flex items-center p-2 text-white rounded-lg hover:bg-gray-700 group">
               <i class="fas fa-ticket-alt w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Destek Talepleri</span>
            </a>
         </li>
         <li>
            <a href="bank.php" class="flex items-center p-2 text-white rounded-lg bg-gray-700 group">
               <i class="fas fa-credit-card w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Bakiye İşlemleri</span>
            </a>
         </li>
         <li>
            <a href="settings.php" class="flex items-center p-2 text-white rounded-lg hover:bg-gray-700 group">
               <i class="fas fa-cog w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Ayarlar</span>
            </a>
         </li>
         <li>
            <a href="logout.php" class="flex items-center p-2 text-white rounded-lg hover:bg-gray-700 group">
               <i class="fas fa-sign-out-alt w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Çıkış Yap</span>
            </a>
         </li>
      </ul>
   </div>
</aside>

<!-- Ana İçerik -->
<div class="p-4 sm:ml-64">
   <div class="p-4 mt-14">
      <!-- İstatistik Kartları -->
      <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
         <div class="bg-[#12122C] rounded-lg p-4 text-white">
            <div class="flex items-center">
               <div class="p-3 rounded-full bg-blue-500 bg-opacity-20">
                  <i class="fas fa-users text-blue-500"></i>
               </div>
               <div class="ml-4">
                  <h3 class="text-xl font-bold"><?= number_format($stats['total_users']) ?></h3>
                  <p class="text-gray-400">Toplam Kullanıcı</p>
               </div>
            </div>
         </div>
         
         <div class="bg-[#12122C] rounded-lg p-4 text-white">
            <div class="flex items-center">
               <div class="p-3 rounded-full bg-green-500 bg-opacity-20">
                  <i class="fas fa-shopping-cart text-green-500"></i>
               </div>
               <div class="ml-4">
                  <h3 class="text-xl font-bold"><?= number_format($stats['total_orders']) ?></h3>
                  <p class="text-gray-400">Toplam Sipariş</p>
               </div>
            </div>
         </div>
         
         <div class="bg-[#12122C] rounded-lg p-4 text-white">
            <div class="flex items-center">
               <div class="p-3 rounded-full bg-purple-500 bg-opacity-20">
                  <i class="fas fa-list text-purple-500"></i>
               </div>
               <div class="ml-4">
                  <h3 class="text-xl font-bold"><?= number_format($stats['total_services']) ?></h3>
                  <p class="text-gray-400">Toplam Servis</p>
               </div>
            </div>
         </div>
         
         <div class="bg-[#12122C] rounded-lg p-4 text-white">
            <div class="flex items-center">
               <div class="p-3 rounded-full bg-yellow-500 bg-opacity-20">
                  <i class="fas fa-ticket-alt text-yellow-500"></i>
               </div>
               <div class="ml-4">
                  <h3 class="text-xl font-bold"><?= number_format($stats['total_tickets']) ?></h3>
                  <p class="text-gray-400">Destek Talepleri</p>
               </div>
            </div>
         </div>
      </div>

      <!-- Son Siparişler ve Son Kullanıcılar -->
      <div class="grid grid-cols-1 lg:grid-cols-2 gap-4">
         <!-- Son Siparişler -->
         <div class="bg-[#12122C] rounded-lg p-4">
            <h2 class="text-xl font-bold text-white mb-4">Son Siparişler</h2>
            <div class="overflow-x-auto">
               <table class="w-full text-sm text-left text-gray-400">
                  <thead class="text-xs uppercase bg-gray-700 text-gray-400">
                     <tr>
                        <th scope="col" class="px-6 py-3">ID</th>
                        <th scope="col" class="px-6 py-3">Kullanıcı</th>
                        <th scope="col" class="px-6 py-3">Servis</th>
                        <th scope="col" class="px-6 py-3">Durum</th>
                     </tr>
                  </thead>
                  <tbody>
                     <?php foreach($recentOrders as $order): ?>
                     <tr class="border-b bg-[#12122C] border-gray-700">
                        <td class="px-6 py-4">#<?= $order['id'] ?></td>
                        <td class="px-6 py-4"><?= htmlspecialchars($order['username']) ?></td>
                        <td class="px-6 py-4"><?= htmlspecialchars($order['service_name']) ?></td>
                        <td class="px-6 py-4">
                           <span class="px-2 py-1 rounded text-xs 
                              <?php
                              switch($order['status']) {
                                 case 'completed':
                                    echo 'bg-green-900 text-green-300';
                                    break;
                                 case 'pending':
                                    echo 'bg-yellow-900 text-yellow-300';
                                    break;
                                 case 'processing':
                                    echo 'bg-blue-900 text-blue-300';
                                    break;
                                 default:
                                    echo 'bg-red-900 text-red-300';
                              }
                              ?>">
                              <?= ucfirst($order['status']) ?>
                           </span>
                        </td>
                     </tr>
                     <?php endforeach; ?>
                  </tbody>
               </table>
            </div>
         </div>

         <!-- Son Kullanıcılar -->
         <div class="bg-[#12122C] rounded-lg p-4">
            <h2 class="text-xl font-bold text-white mb-4">Son Kayıt Olan Kullanıcılar</h2>
            <div class="overflow-x-auto">
               <table class="w-full text-sm text-left text-gray-400">
                  <thead class="text-xs uppercase bg-gray-700 text-gray-400">
                     <tr>
                        <th scope="col" class="px-6 py-3">ID</th>
                        <th scope="col" class="px-6 py-3">Kullanıcı Adı</th>
                        <th scope="col" class="px-6 py-3">E-posta</th>
                        <th scope="col" class="px-6 py-3">Kayıt Tarihi</th>
                     </tr>
                  </thead>
                  <tbody>
                     <?php foreach($recentUsers as $user): ?>
                     <tr class="border-b bg-[#12122C] border-gray-700">
                        <td class="px-6 py-4">#<?= $user['id'] ?></td>
                        <td class="px-6 py-4"><?= htmlspecialchars($user['username']) ?></td>
                        <td class="px-6 py-4"><?= htmlspecialchars($user['email']) ?></td>
                        <td class="px-6 py-4"><?= date('d.m.Y', strtotime($user['created_at'])) ?></td>
                     </tr>
                     <?php endforeach; ?>
                  </tbody>
               </table>
            </div>
         </div>
      </div>
   </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.2.1/flowbite.min.js"></script>
</body>
</html>