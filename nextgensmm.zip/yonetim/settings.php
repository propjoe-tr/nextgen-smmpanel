<?php
ob_start();
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Yönetici girişi kontrolü
if(!isset($_SESSION['admin_id'])) {
    header("Location: giris.php");
    exit();
}

require_once '../config/db.php';

// Yönetici bilgilerini getir
$admin_id = $_SESSION['admin_id'];
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ? AND role = 'admin'");
$stmt->execute([$admin_id]);
$admin = $stmt->fetch();

// Eğer kullanıcı admin değilse yönlendir
if (!$admin || $admin['role'] !== 'admin') {
    header("Location: giris.php");
    exit();
}

$error = false;
$message = '';

// Form gönderildiğinde
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $first_name = trim($_POST['first_name'] ?? '');
    $last_name = trim($_POST['last_name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $current_password = trim($_POST['current_password'] ?? '');
    $new_password = trim($_POST['new_password'] ?? '');
    $confirm_password = trim($_POST['confirm_password'] ?? '');

    // E-posta kontrolü
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = true;
        $message = 'Geçerli bir e-posta adresi giriniz.';
    } else {
        // E-posta benzersizlik kontrolü (kendi e-postası hariç)
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
        $stmt->execute([$email, $admin_id]);
        if ($stmt->fetch()) {
            $error = true;
            $message = 'Bu e-posta adresi başka bir kullanıcı tarafından kullanılıyor.';
        }
    }

    if (!$error) {
        // Şifre değişikliği kontrolü
        if (!empty($current_password)) {
            if (password_verify($current_password, $admin['password'])) {
                if ($new_password === $confirm_password) {
                    if (strlen($new_password) >= 6) {
                        $password_hash = password_hash($new_password, PASSWORD_DEFAULT);
                        $sql = "UPDATE users SET 
                                first_name = ?, 
                                last_name = ?, 
                                email = ?,
                                phone = ?,
                                password = ?,
                                updated_at = NOW()
                                WHERE id = ?";
                        $stmt = $conn->prepare($sql);
                        $stmt->execute([$first_name, $last_name, $email, $phone, $password_hash, $admin_id]);
                        $message = 'Bilgileriniz ve şifreniz başarıyla güncellendi.';
                    } else {
                        $error = true;
                        $message = 'Yeni şifre en az 6 karakter olmalıdır.';
                    }
                } else {
                    $error = true;
                    $message = 'Yeni şifreler eşleşmiyor.';
                }
            } else {
                $error = true;
                $message = 'Mevcut şifre yanlış.';
            }
        } else {
            // Şifre değişikliği yoksa
            $sql = "UPDATE users SET 
                    first_name = ?, 
                    last_name = ?, 
                    email = ?,
                    phone = ?,
                    updated_at = NOW()
                    WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->execute([$first_name, $last_name, $email, $phone, $admin_id]);
            $message = 'Bilgileriniz başarıyla güncellendi.';
        }

        if (!$error) {
            // Güncel bilgileri yeniden çek
            $stmt = $conn->prepare("SELECT * FROM users WHERE id = ? AND role = 'admin'");
            $stmt->execute([$admin_id]);
            $admin = $stmt->fetch();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Hesap Ayarları - NextGen SMM Panel</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.2.1/flowbite.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <style>
        .neo-gradient {
            background: linear-gradient(120deg, #2E3192, #1BFFFF);
        }
        .text-gradient {
            background: linear-gradient(to right, #1BFFFF, #2E3192);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
    </style>
</head>
<body class="bg-[#0A0A1B]">

<button data-drawer-target="logo-sidebar" data-drawer-toggle="logo-sidebar" aria-controls="logo-sidebar" type="button" class="inline-flex items-center p-2 mt-2 ms-3 text-sm text-gray-500 rounded-lg sm:hidden hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200">
   <span class="sr-only">Open sidebar</span>
   <svg class="w-6 h-6" aria-hidden="true" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
      <path clip-rule="evenodd" fill-rule="evenodd" d="M2 4.75A.75.75 0 012.75 4h14.5a.75.75 0 010 1.5H2.75A.75.75 0 012 4.75zm0 10.5a.75.75 0 01.75-.75h7.5a.75.75 0 010 1.5h-7.5a.75.75 0 01-.75-.75zM2 10a.75.75 0 01.75-.75h14.5a.75.75 0 010 1.5H2.75A.75.75 0 012 10z"></path>
   </svg>
</button>

<!-- Sidebar -->
<aside id="logo-sidebar" class="fixed top-0 left-0 z-40 w-64 h-screen transition-transform -translate-x-full sm:translate-x-0" aria-label="Sidebar">
   <div class="h-full px-3 py-4 overflow-y-auto bg-[#12122C]">
      <a href="index.php" class="flex items-center ps-2.5 mb-5">
         <span class="self-center text-xl font-semibold whitespace-nowrap text-white">NextGen <span class="text-gradient">SMM Panel</span></span>
      </a>
      <ul class="space-y-2 font-medium">
         <li>
            <a href="index.php" class="flex items-center p-2 text-white rounded-lg hover:bg-gray-700 group">
               <i class="fas fa-home w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Dashboard</span>
            </a>
         </li>
         <li>
            <a href="users.php" class="flex items-center p-2 text-white rounded-lg hover:bg-gray-700 group">
               <i class="fas fa-users w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Kullanıcılar</span>
            </a>
         </li>
         <li>
            <a href="services.php" class="flex items-center p-2 text-white rounded-lg hover:bg-gray-700 group">
               <i class="fas fa-list w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Servisler</span>
            </a>
         </li>
         <li>
            <a href="orders.php" class="flex items-center p-2 text-white rounded-lg hover:bg-gray-700 group">
               <i class="fas fa-shopping-cart w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Siparişler</span>
            </a>
         </li>
         <li>
            <a href="tickets.php" class="flex items-center p-2 text-white rounded-lg hover:bg-gray-700 group">
               <i class="fas fa-ticket-alt w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Destek Talepleri</span>
            </a>
         </li>
         <li>
            <a href="bank.php" class="flex items-center p-2 text-white rounded-lg bg-gray-700 group">
               <i class="fas fa-credit-card w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Bakiye İşlemleri</span>
            </a>
         </li>
         <li>
            <a href="settings.php" class="flex items-center p-2 text-white rounded-lg hover:bg-gray-700 group">
               <i class="fas fa-cog w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Ayarlar</span>
            </a>
         </li>
         <li>
            <a href="logout.php" class="flex items-center p-2 text-white rounded-lg hover:bg-gray-700 group">
               <i class="fas fa-sign-out-alt w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Çıkış Yap</span>
            </a>
         </li>
      </ul>
   </div>
</aside>

<!-- Ana İçerik -->
<div class="p-4 sm:ml-64">
    <div class="p-4 mt-14">
        <div class="bg-[#12122C] rounded-lg p-6 max-w-2xl mx-auto">
            <h2 class="text-2xl font-bold text-white mb-6">Hesap Ayarları</h2>

            <?php if ($message): ?>
            <div class="p-4 mb-6 rounded-lg <?= $error ? 'bg-red-900 text-red-300' : 'bg-green-900 text-green-300' ?>">
                <?= htmlspecialchars($message) ?>
            </div>
            <?php endif; ?>

            <form method="POST" class="space-y-6">
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                        <label class="block text-gray-300 mb-2">Ad</label>
                        <input type="text" name="first_name" value="<?= htmlspecialchars($admin['first_name'] ?? '') ?>" 
                               class="w-full bg-[#1E1E45] text-white rounded-lg p-3 focus:ring-blue-500">
                    </div>
                    <div>
                        <label class="block text-gray-300 mb-2">Soyad</label>
                        <input type="text" name="last_name" value="<?= htmlspecialchars($admin['last_name'] ?? '') ?>" 
                               class="w-full bg-[#1E1E45] text-white rounded-lg p-3 focus:ring-blue-500">
                    </div>
                </div>

                <div>
                    <label class="block text-gray-300 mb-2">E-posta</label>
                    <input type="email" name="email" value="<?= htmlspecialchars($admin['email']) ?>" 
                           class="w-full bg-[#1E1E45] text-white rounded-lg p-3 focus:ring-blue-500">
                </div>

                <div>
                    <label class="block text-gray-300 mb-2">Telefon</label>
                    <input type="tel" name="phone" value="<?= htmlspecialchars($admin['phone'] ?? '') ?>" 
                           class="w-full bg-[#1E1E45] text-white rounded-lg p-3 focus:ring-blue-500">
                </div>

                <div class="border-t border-gray-700 pt-6">
                    <h3 class="text-xl font-bold text-white mb-4">Şifre Değiştir</h3>
                    
                    <div class="space-y-4">
                        <div>
                            <label class="block text-gray-300 mb-2">Mevcut Şifre</label>
                            <input type="password" name="current_password" 
                                   class="w-full bg-[#1E1E45] text-white rounded-lg p-3 focus:ring-blue-500">
                        </div>
                        
                        <div>
                            <label class="block text-gray-300 mb-2">Yeni Şifre</label>
                            <input type="password" name="new_password" 
                                   class="w-full bg-[#1E1E45] text-white rounded-lg p-3 focus:ring-blue-500">
                        </div>
                        
                        <div>
                            <label class="block text-gray-300 mb-2">Yeni Şifre (Tekrar)</label>
                            <input type="password" name="confirm_password" 
                                   class="w-full bg-[#1E1E45] text-white rounded-lg p-3 focus:ring-blue-500">
                        </div>
                    </div>
                </div>

                <div class="flex justify-end">
                    <button type="submit" 
                            class="bg-blue-600 hover:bg-blue-700 text-white font-bold py-3 px-6 rounded-lg">
                        Değişiklikleri Kaydet
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.2.1/flowbite.min.js"></script>
</body>
</html>
<?php ob_end_flush(); ?>