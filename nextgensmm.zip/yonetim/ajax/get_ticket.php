<?php
session_start();
if(!isset($_SESSION['admin_id'])) {
    die('Yetkisiz erişim');
}

require_once '../../config/db.php';

$ticket_id = $_GET['id'] ?? 0;

// Destek talebi detaylarını getir
$stmt = $conn->prepare("
    SELECT t.*, u.username 
    FROM tickets t 
    JOIN users u ON t.user_id = u.id 
    WHERE t.id = ?
");
$stmt->execute([$ticket_id]);
$ticket = $stmt->fetch();

if(!$ticket) {
    die('Destek talebi bulunamadı');
}

// Yanıtları getir
$stmt = $conn->prepare("
    SELECT r.*, u.username, u.role 
    FROM ticket_replies r 
    JOIN users u ON r.user_id = u.id 
    WHERE r.ticket_id = ? 
    ORDER BY r.created_at ASC
");
$stmt->execute([$ticket_id]);
$replies = $stmt->fetchAll();
?>

<div class="mb-4 p-4 bg-gray-800 rounded">
    <div class="flex justify-between items-start">
        <div>
            <h4 class="text-lg font-bold text-white"><?= htmlspecialchars($ticket['subject']) ?></h4>
            <p class="text-sm text-gray-400">
                <?= htmlspecialchars($ticket['username']) ?> tarafından 
                <?= date('d.m.Y H:i', strtotime($ticket['created_at'])) ?>
            </p>
        </div>
        <span class="px-2 py-1 rounded text-xs 
            <?php
            switch($ticket['priority']) {
                case 'high':
                    echo 'bg-red-900 text-red-300';
                    break;
                case 'medium':
                    echo 'bg-yellow-900 text-yellow-300';
                    break;
                default:
                    echo 'bg-blue-900 text-blue-300';
            }
            ?>">
            <?= ucfirst($ticket['priority']) ?>
        </span>
    </div>
    <div class="mt-4 text-gray-300">
        <?= nl2br(htmlspecialchars($ticket['message'])) ?>
    </div>
</div>

<?php foreach($replies as $reply): ?>
<div class="mb-4 p-4 <?= $reply['role'] == 'admin' ? 'bg-blue-900 bg-opacity-20' : 'bg-gray-800' ?> rounded">
    <div class="flex justify-between items-start">
        <p class="text-sm text-gray-400">
            <?= htmlspecialchars($reply['username']) ?> 
            <?= $reply['role'] == 'admin' ? '<span class="text-blue-400">(Yönetici)</span>' : '' ?>
            - <?= date('d.m.Y H:i', strtotime($reply['created_at'])) ?>
        </p>
    </div>
    <div class="mt-2 text-gray-300">
        <?= nl2br(htmlspecialchars($reply['message'])) ?>
    </div>
</div>
<?php endforeach; ?>