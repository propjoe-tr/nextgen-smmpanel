<?php
ob_start();
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Yönetici girişi kontrolü
if(!isset($_SESSION['admin_id'])) {
    header("Location: giris.php");
    exit();
}

require_once '../config/db.php';

// Destek talebi işlemleri
if($_SERVER['REQUEST_METHOD'] == 'POST') {
    if(isset($_POST['action'])) {
        switch($_POST['action']) {
            case 'reply':
                $ticket_id = $_POST['ticket_id'];
                $message = trim($_POST['message']);
                if(!empty($message)) {
                    $stmt = $conn->prepare("INSERT INTO ticket_replies (ticket_id, user_id, message) VALUES (?, ?, ?)");
                    $stmt->execute([$ticket_id, $_SESSION['admin_id'], $message]);
                    
                    // Destek talebinin durumunu güncelle
                    $stmt = $conn->prepare("UPDATE tickets SET status = 'answered', updated_at = CURRENT_TIMESTAMP WHERE id = ?");
                    $stmt->execute([$ticket_id]);
                }
                break;
                
            case 'close':
                $ticket_id = $_POST['ticket_id'];
                $stmt = $conn->prepare("UPDATE tickets SET status = 'closed', updated_at = CURRENT_TIMESTAMP WHERE id = ?");
                $stmt->execute([$ticket_id]);
                break;
                
            case 'delete':
                $ticket_id = $_POST['ticket_id'];
                $stmt = $conn->prepare("DELETE FROM tickets WHERE id = ?");
                $stmt->execute([$ticket_id]);
                break;
        }
        header("Location: tickets.php");
        exit();
    }
}

// Destek taleplerini çek
$tickets = $conn->query("
    SELECT t.*, u.username, 
    (SELECT COUNT(*) FROM ticket_replies WHERE ticket_id = t.id) as reply_count 
    FROM tickets t 
    JOIN users u ON t.user_id = u.id 
    ORDER BY t.status = 'open' DESC, t.created_at DESC
")->fetchAll();
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Destek Talepleri - NextGen SMM Panel</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.2.1/flowbite.min.css" rel="stylesheet" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        .neo-gradient {
            background: linear-gradient(120deg, #2E3192, #1BFFFF);
        }
        .text-gradient {
            background: linear-gradient(to right, #1BFFFF, #2E3192);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }
    </style>
</head>
<body class="bg-[#0A0A1B]">

<button data-drawer-target="logo-sidebar" data-drawer-toggle="logo-sidebar" aria-controls="logo-sidebar" type="button" class="inline-flex items-center p-2 mt-2 ms-3 text-sm text-gray-500 rounded-lg sm:hidden hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-gray-200">
   <span class="sr-only">Open sidebar</span>
   <svg class="w-6 h-6" aria-hidden="true" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
      <path clip-rule="evenodd" fill-rule="evenodd" d="M2 4.75A.75.75 0 012.75 4h14.5a.75.75 0 010 1.5H2.75A.75.75 0 012 4.75zm0 10.5a.75.75 0 01.75-.75h7.5a.75.75 0 010 1.5h-7.5a.75.75 0 01-.75-.75zM2 10a.75.75 0 01.75-.75h14.5a.75.75 0 010 1.5H2.75A.75.75 0 012 10z"></path>
   </svg>
</button>

<!-- Sidebar -->
<aside id="logo-sidebar" class="fixed top-0 left-0 z-40 w-64 h-screen transition-transform -translate-x-full sm:translate-x-0" aria-label="Sidebar">
   <div class="h-full px-3 py-4 overflow-y-auto bg-[#12122C]">
      <a href="index.php" class="flex items-center ps-2.5 mb-5">
         <span class="self-center text-xl font-semibold whitespace-nowrap text-white">NextGen <span class="text-gradient">SMM Panel</span></span>
      </a>
      <ul class="space-y-2 font-medium">
         <li>
            <a href="index.php" class="flex items-center p-2 text-white rounded-lg hover:bg-gray-700 group">
               <i class="fas fa-home w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Dashboard</span>
            </a>
         </li>
         <li>
            <a href="users.php" class="flex items-center p-2 text-white rounded-lg hover:bg-gray-700 group">
               <i class="fas fa-users w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Kullanıcılar</span>
            </a>
         </li>
         <li>
            <a href="services.php" class="flex items-center p-2 text-white rounded-lg hover:bg-gray-700 group">
               <i class="fas fa-list w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Servisler</span>
            </a>
         </li>
         <li>
            <a href="orders.php" class="flex items-center p-2 text-white rounded-lg hover:bg-gray-700 group">
               <i class="fas fa-shopping-cart w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Siparişler</span>
            </a>
         </li>
         <li>
            <a href="tickets.php" class="flex items-center p-2 text-white rounded-lg hover:bg-gray-700 group">
               <i class="fas fa-ticket-alt w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Destek Talepleri</span>
            </a>
         </li>
         <li>
            <a href="bank.php" class="flex items-center p-2 text-white rounded-lg bg-gray-700 group">
               <i class="fas fa-credit-card w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Bakiye İşlemleri</span>
            </a>
         </li>
         <li>
            <a href="settings.php" class="flex items-center p-2 text-white rounded-lg hover:bg-gray-700 group">
               <i class="fas fa-cog w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Ayarlar</span>
            </a>
         </li>
         <li>
            <a href="logout.php" class="flex items-center p-2 text-white rounded-lg hover:bg-gray-700 group">
               <i class="fas fa-sign-out-alt w-5 h-5 text-gray-400 transition duration-75 group-hover:text-white"></i>
               <span class="ms-3">Çıkış Yap</span>
            </a>
         </li>
      </ul>
   </div>
</aside>

<!-- Ana İçerik -->
<div class="p-4 sm:ml-64">
    <div class="p-4 mt-14">
        <div class="bg-[#12122C] rounded-lg p-4">
            <div class="flex justify-between items-center mb-4">
                <h2 class="text-xl font-bold text-white">Destek Talepleri</h2>
            </div>
            
            <div class="overflow-x-auto">
                <table class="w-full text-sm text-left text-gray-400">
                    <thead class="text-xs uppercase bg-gray-700 text-gray-400">
                        <tr>
                            <th scope="col" class="px-6 py-3">ID</th>
                            <th scope="col" class="px-6 py-3">Kullanıcı</th>
                            <th scope="col" class="px-6 py-3">Konu</th>
                            <th scope="col" class="px-6 py-3">Öncelik</th>
                            <th scope="col" class="px-6 py-3">Durum</th>
                            <th scope="col" class="px-6 py-3">Yanıtlar</th>
                            <th scope="col" class="px-6 py-3">Tarih</th>
                            <th scope="col" class="px-6 py-3">İşlemler</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($tickets as $ticket): ?>
                        <tr class="border-b bg-[#12122C] border-gray-700">
                            <td class="px-6 py-4">#<?= $ticket['id'] ?></td>
                            <td class="px-6 py-4"><?= htmlspecialchars($ticket['username']) ?></td>
                            <td class="px-6 py-4"><?= htmlspecialchars($ticket['subject']) ?></td>
                            <td class="px-6 py-4">
                                <span class="px-2 py-1 rounded text-xs 
                                    <?php
                                    switch($ticket['priority']) {
                                        case 'high':
                                            echo 'bg-red-900 text-red-300';
                                            break;
                                        case 'medium':
                                            echo 'bg-yellow-900 text-yellow-300';
                                            break;
                                        default:
                                            echo 'bg-blue-900 text-blue-300';
                                    }
                                    ?>">
                                    <?= ucfirst($ticket['priority']) ?>
                                </span>
                            </td>
                            <td class="px-6 py-4">
                                <span class="px-2 py-1 rounded text-xs 
                                    <?php
                                    switch($ticket['status']) {
                                        case 'open':
                                            echo 'bg-green-900 text-green-300';
                                            break;
                                        case 'answered':
                                            echo 'bg-blue-900 text-blue-300';
                                            break;
                                        default:
                                            echo 'bg-gray-900 text-gray-300';
                                    }
                                    ?>">
                                    <?= ucfirst($ticket['status']) ?>
                                </span>
                            </td>
                            <td class="px-6 py-4"><?= $ticket['reply_count'] ?></td>
                            <td class="px-6 py-4"><?= date('d.m.Y H:i', strtotime($ticket['created_at'])) ?></td>
                            <td class="px-6 py-4">
                                <button onclick="viewTicket(<?= $ticket['id'] ?>)" class="text-blue-500 hover:text-blue-700">
                                    <i class="fas fa-eye"></i>
                                </button>
                                <?php if($ticket['status'] != 'closed'): ?>
                                <button onclick="closeTicket(<?= $ticket['id'] ?>)" class="ml-2 text-yellow-500 hover:text-yellow-700">
                                    <i class="fas fa-lock"></i>
                                </button>
                                <?php endif; ?>
                                <button onclick="deleteTicket(<?= $ticket['id'] ?>)" class="ml-2 text-red-500 hover:text-red-700">
                                    <i class="fas fa-trash"></i>
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Destek Talebi Görüntüleme Modalı -->
<div id="ticketModal" tabindex="-1" aria-hidden="true" class="hidden overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 z-50 justify-center items-center w-full md:inset-0 h-[calc(100%-1rem)] max-h-full">
    <div class="relative p-4 w-full max-w-2xl max-h-full">
        <div class="relative bg-[#12122C] rounded-lg shadow">
            <div class="flex items-center justify-between p-4 md:p-5 border-b rounded-t border-gray-600">
                <h3 class="text-xl font-semibold text-white" id="modalTitle">
                    Destek Talebi Detayı
                </h3>
                <button type="button" onclick="closeModal()" class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ms-auto inline-flex justify-center items-center dark:hover:bg-gray-600 dark:hover:text-white">
                    <i class="fas fa-times"></i>
                </button>
            </div>
            <div class="p-4 md:p-5 space-y-4">
                <div id="ticketContent" class="text-gray-300">
                    <!-- AJAX ile yüklenecek içerik -->
                </div>
                <form id="replyForm" class="mt-4">
                    <input type="hidden" name="action" value="reply">
                    <input type="hidden" name="ticket_id" id="replyTicketId">
                    <textarea name="message" class="w-full p-2 bg-gray-700 text-white rounded" rows="3" placeholder="Yanıtınızı yazın..."></textarea>
                    <button type="submit" class="mt-2 px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">Yanıtla</button>
                </form>
            </div>
        </div>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.2.1/flowbite.min.js"></script>
<script>
function viewTicket(id) {
    fetch(`ajax/get_ticket.php?id=${id}`, {
        credentials: 'same-origin'
    })
    .then(response => response.text())
    .then(data => {
        document.getElementById('ticketContent').innerHTML = data;
        document.getElementById('replyTicketId').value = id;
        const modal = document.getElementById('ticketModal');
        modal.classList.remove('hidden');
        modal.classList.add('flex');
    })
    .catch(error => {
        console.error('Hata:', error);
        alert('Destek talebi yüklenirken bir hata oluştu.');
    });
}

function closeModal() {
    const modal = document.getElementById('ticketModal');
    modal.classList.add('hidden');
    modal.classList.remove('flex');
}

function closeTicket(id) {
    if(confirm('Bu destek talebini kapatmak istediğinize emin misiniz?')) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.innerHTML = `
            <input type="hidden" name="action" value="close">
            <input type="hidden" name="ticket_id" value="${id}">
        `;
        document.body.appendChild(form);
        form.submit();
    }
}

function deleteTicket(id) {
    if(confirm('Bu destek talebini silmek istediğinize emin misiniz?')) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.innerHTML = `
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="ticket_id" value="${id}">
        `;
        document.body.appendChild(form);
        form.submit();
    }
}

// Form submit işlemi
document.getElementById('replyForm').addEventListener('submit', function(e) {
    e.preventDefault();
    const formData = new FormData(this);
    fetch('tickets.php', {
        method: 'POST',
        body: formData
    }).then(() => {
        location.reload();
    });
});
</script>
</body>
</html>